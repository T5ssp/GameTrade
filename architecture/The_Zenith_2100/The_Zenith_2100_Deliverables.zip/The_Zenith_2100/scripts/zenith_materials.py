import bpy

def pbr(name,color,metallic=0,roughness=.4,transmission=0,emission=0):
    mat=bpy.data.materials.new(name);mat.use_nodes=True
    bs=mat.node_tree.nodes.get('Principled BSDF');bs.inputs['Base Color'].default_value=(*color,1);bs.inputs['Metallic'].default_value=metallic;bs.inputs['Roughness'].default_value=roughness
    bs.inputs['IOR'].default_value=1.46
    bs.inputs['Transmission Weight'].default_value=transmission
    if emission:
        bs.inputs['Emission Color'].default_value=(*color,1);bs.inputs['Emission Strength'].default_value=emission
    mat.diffuse_color=(*color,.25 if transmission else 1)
    return mat

def build_materials():
    M={
     'titanium':pbr('PBR | Brushed champagne titanium',(.23,.28,.30),.8,.27),
     'gold':pbr('PBR | Satin architectural gold',(.64,.39,.12),.82,.24),
     'ivory':pbr('PBR | Warm porcelain composite',(.77,.74,.66),.12,.29),
     'stone':pbr('PBR | Honed ivory limestone',(.68,.64,.54),.05,.43),
     'floor':pbr('PBR | Veined pearl terrazzo',(.49,.52,.51),.08,.24),
     'wood':pbr('PBR | Smoked walnut acoustic timber',(.115,.064,.036),.03,.43),
     'glass':pbr('PBR | Low-iron smart glass',(.76,.91,.94),.05,.055,1),
     'dark_glass':pbr('PBR | Electrochromic blue glass',(.04,.13,.19),.16,.12,.72),
     'black':pbr('PBR | Graphite ceramic',(.012,.021,.028),.25,.26),
     'water':pbr('PBR | Reflecting pool water',(.08,.23,.26),.04,.07,.78),
     'leaf':pbr('PBR | Living garden foliage',(.09,.22,.09),0,.65),
     'light_warm':pbr('LUM | Warm integrated light 3000K',(1,.64,.29),0,.25,0,4),
     'light_cool':pbr('LUM | Cyan navigation inlay',(.15,.65,.86),.1,.3,0,3),
     'screen':pbr('LUM | Interactive interface',(.025,.24,.34),.2,.2,0,.8),
     'steel':pbr('PBR | Commercial brushed steel',(.42,.48,.51),.87,.23),
     'fabric':pbr('PBR | Deep teal woven upholstery',(.028,.105,.12),0,.76),
     'solar':pbr('PBR | Photovoltaic laminated cells',(.015,.04,.075),.65,.19),
     'holo':pbr('LUM | Holographic menu glass',(.03,.55,.72),.05,.12,.45,1.2),
     'earth':pbr('PBR | Planter growing substrate',(.04,.025,.014),0,.95)
    }
    for key in ['stone','floor','wood','fabric']:
        mat=M[key];nodes=mat.node_tree.nodes;links=mat.node_tree.links;bs=nodes.get('Principled BSDF')
        noise=nodes.new('ShaderNodeTexNoise');noise.name='Editable material microtexture';noise.inputs['Scale'].default_value=95 if key=='fabric' else 4;noise.inputs['Detail'].default_value=3
        bump=nodes.new('ShaderNodeBump');bump.inputs['Strength'].default_value=.14 if key=='fabric' else .11;bump.inputs['Distance'].default_value=.025 if key=='floor' else .012
        links.new(noise.outputs['Fac'],bump.inputs['Height']);links.new(bump.outputs['Normal'],bs.inputs['Normal'])
        if key in ('stone','floor'):
            ramp=nodes.new('ShaderNodeValToRGB');ramp.color_ramp.elements[0].position=.25;ramp.color_ramp.elements[0].color=(.28,.32,.33,1);ramp.color_ramp.elements[1].position=.67;ramp.color_ramp.elements[1].color=(.7,.72,.68,1)
            links.new(noise.outputs['Fac'],ramp.inputs[0]);links.new(ramp.outputs[0],bs.inputs['Base Color'])
    return M
