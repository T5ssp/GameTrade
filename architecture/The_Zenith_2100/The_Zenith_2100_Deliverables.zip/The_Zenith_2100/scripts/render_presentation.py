"""Cycles renders + checksum-verified official Intel OIDN CPU denoising.
Uses genuine scene geometry. No generative image changes or external textures.
blender -b Zenith2100.blend --threads 5 --python scripts/render_presentation.py -- --shots all --profile presentation
"""
import bpy,sys,json,argparse,time,subprocess,os,struct,zlib
from pathlib import Path
import numpy as np
ROOT=Path(__file__).resolve().parents[1]
args=sys.argv[sys.argv.index('--')+1:] if '--' in sys.argv else []
p=argparse.ArgumentParser();p.add_argument('--shots',default='all');p.add_argument('--profile',choices=['proof','presentation','final'],default='presentation');p.add_argument('--overwrite',action='store_true');cfg=p.parse_args(args)
OIDN=ROOT/'tools/oidn-2.5.1.x86_64.linux/bin/oidnDenoise'
if not OIDN.is_file():raise RuntimeError('Official approved OIDN executable missing. Use render_zenith.py for an unfiltered Cycles render instead.')
if not json.loads((ROOT/'logs/oidn_installation.json').read_text()).get('verified'):raise RuntimeError('Denoiser integrity verification has not passed.')
rawdir=ROOT/'renders/raw';rawdir.mkdir(exist_ok=True);outdir=ROOT/('renders/proofs' if cfg.profile=='proof' else 'renders');outdir.mkdir(exist_ok=True)
scene=bpy.context.scene;scene.use_nodes=False;scene.render.engine='CYCLES';scene.cycles.device='CPU';scene.cycles.use_denoising=False
scene.cycles.use_adaptive_sampling=True;scene.cycles.adaptive_threshold=.06
scene.render.threads_mode='FIXED';scene.render.threads=5
manifest=json.loads((ROOT/'cameras/camera_manifest.json').read_text())
shots=manifest if cfg.shots=='all' else [c for c in manifest if c['name'][:2] in cfg.shots.split(',')]
report_file=ROOT/'logs'/('presentation_'+cfg.profile+'.json')
try:report=json.loads(report_file.read_text()) if report_file.exists() else []
except ValueError:report=[]

def verified_output(path,name,dimensions):
    entry=next((row for row in report if row.get('camera')==name and row.get('verified')),None)
    if not entry or not path.is_file() or path.stat().st_mtime<(ROOT/'Zenith2100.blend').stat().st_mtime:return False
    try:
        content=path.read_bytes()
        if content[:8]!=b'\x89PNG\r\n\x1a\n' or struct.unpack('>II',content[16:24])!=dimensions:return False
        at=8;ended=False
        while at<len(content):
            length=struct.unpack('>I',content[at:at+4])[0];kind=content[at+4:at+8];payload=content[at+8:at+8+length];crc=struct.unpack('>I',content[at+8+length:at+12+length])[0]
            if zlib.crc32(kind+payload)&0xffffffff!=crc:return False
            at+=length+12
            if kind==b'IEND':ended=True;break
        return ended and at==len(content)
    except (OSError,ValueError,struct.error):return False

def write_pfm(path,rgb):
    with path.open('wb') as f:
        f.write(f'PF\n{rgb.shape[1]} {rgb.shape[0]}\n-1.0\n'.encode());f.write(np.asarray(rgb,dtype='<f4').tobytes())

def read_pfm(path):
    with path.open('rb') as f:
        assert f.readline().strip()==b'PF','Not a color PFM'
        dims=f.readline()
        while dims.startswith(b'#'):dims=f.readline()
        w,h=map(int,dims.split());scale=float(f.readline());dtype='<f4' if scale<0 else '>f4';data=np.frombuffer(f.read(),dtype=dtype)
        assert data.size==w*h*3,'Incorrect PFM length'
        return data.reshape(h,w,3).copy()

for camera in shots:
    name=camera['name'];output=outdir/(name+'.png')
    if cfg.profile=='proof':w,h,samples=800,600,24
    elif cfg.profile=='final':w,h,samples=(2000,1500,128) if name.startswith('01') else (1600,1200,96)
    else:w,h,samples=(1600,1200,48) if name.startswith('01') else (1280,960,32)
    if not cfg.overwrite and verified_output(output,name,(w,h)):
        print('ZENITH_VERIFIED_RENDER_RESUME_SKIP',name,flush=True);continue
    scene.render.resolution_x=w;scene.render.resolution_y=h;scene.render.resolution_percentage=100;scene.cycles.samples=samples
    scene.camera=bpy.data.objects[name]
    for layer in scene.view_layers:layer.use=layer.name==camera['view_layer']
    scene.render.image_settings.file_format='OPEN_EXR';scene.render.image_settings.color_mode='RGB';scene.render.image_settings.color_depth='32'
    raw=rawdir/(name+'.exr');scene.render.filepath=str(raw);started=time.time()
    print('ZENITH_PRESENTATION_START',name,w,h,samples,flush=True)
    bpy.ops.render.render(write_still=True,layer=camera['view_layer'])
    source=bpy.data.images.load(str(raw),check_existing=False)
    data=np.empty(w*h*4,dtype=np.float32);source.pixels.foreach_get(data);rgb=data.reshape(h,w,4)[:,:,:3].copy();bpy.data.images.remove(source)
    assert np.isfinite(rgb).all(),'Non-finite render pixels'
    inputpfm=rawdir/(name+'_input.pfm');cleanpfm=rawdir/(name+'_clean.pfm');write_pfm(inputpfm,rgb)
    run=subprocess.run([str(OIDN),'--device','cpu','--hdr',str(inputpfm),'--output',str(cleanpfm),'--quality','high','--threads','5'],capture_output=True,text=True)
    (ROOT/'logs'/(name+'_oidn.log')).write_text(run.stdout+'\n'+run.stderr)
    if run.returncode:raise RuntimeError('Denoiser failed: '+run.stderr+run.stdout)
    clean=read_pfm(cleanpfm)
    assert clean.shape==(h,w,3) and np.isfinite(clean).all(),'Invalid cleaned image'
    assert float(clean.max()-clean.min())>.01,'Blank image'
    rgba=np.ones((h,w,4),dtype=np.float32);rgba[:,:,:3]=clean
    image=bpy.data.images.new(name+'_Presentation',width=w,height=h,float_buffer=True)
    image.colorspace_settings.name='Linear Rec.709';image.pixels.foreach_set(rgba.ravel());image.update()
    scene.render.image_settings.file_format='PNG';scene.render.image_settings.color_mode='RGB';scene.render.image_settings.color_depth='8'
    temporary_output=output.with_name(output.stem+'.partial.png')
    image.save_render(str(temporary_output),scene=scene);bpy.data.images.remove(image);os.replace(temporary_output,output)
    assert output.is_file() and output.stat().st_size>10000,'Output missing'
    result={'camera':name,'file':str(output.relative_to(ROOT)),'dimensions':[w,h],'cycles_samples':samples,'render_engine':'Cycles CPU','denoiser':'Intel Open Image Denoise 2.5.1 CPU / RT high','seconds':round(time.time()-started,2),'bytes':output.stat().st_size,'finite_pixels':True,'verified':True}
    report=[r for r in report if r['camera']!=name]+[result];temporary_report=report_file.with_suffix('.json.tmp');temporary_report.write_text(json.dumps(report,indent=2));os.replace(temporary_report,report_file)
    print('ZENITH_PRESENTATION_OK',json.dumps(result),flush=True)
