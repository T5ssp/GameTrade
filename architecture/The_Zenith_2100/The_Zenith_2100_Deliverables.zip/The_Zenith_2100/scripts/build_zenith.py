"""Build the editable architectural model, validate each stage and save the .blend.
Run: blender -b --factory-startup --threads 5 --python scripts/build_zenith.py
"""
import bpy,sys,math,json,time
from pathlib import Path
from mathutils import Vector
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'scripts'))
from zenith_lib import cube,cylinder,sphere,curve,text,mesh,collection,ellipse,slab,ring_slab,beam,aim
from zenith_materials import build_materials
for name in ['renders','logs','checkpoints','cameras','exports','docs']:(ROOT/name).mkdir(exist_ok=True)
bpy.ops.wm.read_factory_settings(use_empty=True)
scene=bpy.context.scene
scene.unit_settings.system='METRIC';scene.unit_settings.length_unit='METERS';scene.unit_settings.scale_length=1
scene['Project']='THE ZENITH 2100 | Futuristic Luxury Restaurant'
scene['Design_intent']='Split-petal titanium roofs around a daylit atrium; separate guest and service circulation.'
scene['Ground_FFL_m']=.55;scene['Upper_FFL_m']=5.25
scene['Architectural_status']='University concept model; structural, fire and accessibility compliance require licensed consultant review.'
M=build_materials();STAGES=[]

def validate(stage):
    bpy.context.view_layer.update();problems=[];counts={'objects':len(scene.objects),'mesh_objects':0,'vertices':0,'faces':0}
    for obj in scene.objects:
        if not all(math.isfinite(v) for row in obj.matrix_world for v in row):problems.append('Nonfinite transform: '+obj.name)
        if obj.type=='MESH':
            counts['mesh_objects']+=1;counts['vertices']+=len(obj.data.vertices);counts['faces']+=len(obj.data.polygons)
            if not obj.data.polygons:problems.append('Empty mesh: '+obj.name)
            if not obj.data.materials:problems.append('Unassigned material: '+obj.name)
    report={'stage':stage,'counts':counts,'errors':problems,'validated':not problems}
    STAGES.append(report);(ROOT/'logs'/'build_validation.json').write_text(json.dumps(STAGES,indent=2))
    if problems:raise RuntimeError('\n'.join(problems))
    bpy.ops.wm.save_as_mainfile(filepath=str(ROOT/'checkpoints'/f'{stage}.blend'))
    print('ZENITH_STAGE_OK',stage,json.dumps(counts),flush=True)

# Stage 1. Raised ellipse plate, framed glazing and distinct double-petal roofs.
foot=[(22.7*math.cos(math.tau*i/128),14.4*math.sin(math.tau*i/128)) for i in range(128)]
slab('Ground_Organic_Plinth',foot,.55,.60,M['stone'],'10_Ground_Structure')
curve('Ground_Plinth_Gold_Reveal',ellipse(22.73,14.43,.39),.035,M['gold'],'10_Ground_Structure')
for i in range(16):
    t=math.tau*i/16
    if math.sin(t)<-.94:continue
    beam(f'Primary_Perimeter_Column_{i:02}',(21.2*math.cos(t),13.1*math.sin(t),.55),(21.0*math.cos(t),12.9*math.sin(t),10.45),.25,M['titanium'],'10_Primary_Frame')
    curve(f'Column_Gold_Inlay_{i:02}',[(21.08*math.cos(t),13.0*math.sin(t),.7),(20.88*math.cos(t),12.8*math.sin(t),10.2)],.028,M['gold'],'10_Primary_Frame')
for level,z0,z1 in [('Ground',.65,4.90),('Upper',5.40,10.35)]:
    for i in range(64):
        t0=math.tau*i/64;t1=math.tau*(i+1)/64
        tm=(t0+t1)/2
        if level=='Ground' and math.sin(tm)<-.95 and abs(22*math.cos(tm))<3.3:continue
        a,b=(22,13.8) if level=='Ground' else (21.55,13.35)
        points=[(a*math.cos(t0),b*math.sin(t0),z0),(a*math.cos(t1),b*math.sin(t1),z0),(a*math.cos(t1),b*math.sin(t1),z1),(a*math.cos(t0),b*math.sin(t0),z1)]
        coll='11_Glass_South' if math.sin(tm)<-.1 else '11_Glass_North'
        if math.sin(tm)>.60 and level=='Ground':
            material=M['ivory']
        else:material=M['glass']
        obj=mesh(f'{level}_SmartGlass_Panel_{i:02}',points,[(0,1,2,3)],material,coll)
        solid=obj.modifiers.new('Insulating_Glass_Thickness_35mm','SOLIDIFY');solid.thickness=.035
        beam(f'{level}_Facade_Mullion_{i:02}',points[0],points[3],.055,M['gold'],'11_Facade_Frames')
    curve(f'{level}_Glazing_Top_Rail',ellipse(a,b,z1),.065,M['titanium'],'11_Facade_Frames')
# Continuous middle-floor fascia makes the upper volume read as an elegant cantilever.
for a,b,z,r,mat in [(22.35,14.05,5.03,.18,'titanium'),(22.4,14.1,4.84,.035,'gold'),(22.4,14.1,5.20,.025,'light_warm')]:
    curve('Cantilever_Facade_Ribbon_'+mat,ellipse(a,b,z),r,M[mat],'11_Facade_Frames')

def roof_point(t,u):
    x=(7.5+(26.3-7.5)*u)*math.cos(t)
    y=-.5+(5.8+(16.3-5.8)*u)*math.sin(t)
    z=11.8+1.05*math.sin(2*t+.5)+.85*math.sin(math.pi*u)+.45*u*math.cos(t)
    return (x,y,z)
for side,tstart,tend in [('East',-math.pi/2+.055,math.pi/2-.055),('West',math.pi/2+.055,math.pi*1.5-.055)]:
    nu,nv=15,80;verts=[]
    for j in range(nv+1):
        t=tstart+(tend-tstart)*j/nv
        for i in range(nu+1):verts.append(roof_point(t,i/nu))
    faces=[]
    for j in range(nv):
        for i in range(nu):
            a=j*(nu+1)+i;faces.append((a,a+1,a+nu+2,a+nu+1))
    obj=mesh(f'Roof_{side}_Sculpted_Petal',verts,faces,M['titanium'],'12_Roof')
    for p in obj.data.polygons:p.use_smooth=True
    solid=obj.modifiers.new('Composite_Shell_180mm','SOLIDIFY');solid.thickness=.18
    for u,label,r in [(0,'Oculus_Inner_Edge',.08),(1,'Cantilever_Outer_Edge',.10)]:
        curve(f'{side}_{label}',[roof_point(tstart+(tend-tstart)*j/160,u) for j in range(161)],r,M['gold'],'12_Roof')
    for i in range(9):
        t=tstart+(tend-tstart)*(i+.5)/9
        curve(f'{side}_Roof_Rib_{i:02}',[(x,y,z-.19) for x,y,z in [roof_point(t,k/35) for k in range(36)]],.075,M['ivory'],'12_Roof')
# Oculus glazing: individually editable translucent facets and titanium lattice.
for j in range(5):
    f0=j/5;f1=(j+1)/5
    for i in range(40):
        t0=math.tau*i/40;t1=math.tau*(i+1)/40
        def dome(t,f):
            edge=roof_point(t,0)
            return (edge[0]*f,-.5+(edge[1]+.5)*f,14.1*(1-f)+edge[2]*f+.55*math.sin(math.pi*f))
        verts=[dome(t0,f0),dome(t1,f0),dome(t1,f1),dome(t0,f1)]
        mesh(f'Oculus_SmartGlass_{j}_{i}',verts,[(0,1,2,3)],M['glass'],'14_Oculus_Glass')
for i in range(16):
    t=math.tau*i/16
    curve(f'Oculus_Radial_Rib_{i:02}',[(7.5*f*math.cos(t),-.5+5.8*f*math.sin(t),14.1*(1-f)+roof_point(t,0)[2]*f+.55*math.sin(math.pi*f)) for f in [k/20 for k in range(21)]],.035,M['gold'],'14_Oculus_Frame')
# Entrance frame and architectural wordmark, front-facing rather than a floating billboard.
for x in [-3.3,3.3]:cube('Entrance_Gold_Jamb', (x,-13.86,2.75),(.18,.25,4.4),M['gold'],'15_Entrance',.04)
cube('Entrance_Header',(0,-13.86,4.98),(6.8,.35,.32),M['titanium'],'15_Entrance',.05)
for x in [-2.65,2.65]:cube('Partly_Open_SmartGlass_Door',(x,-13.91,2.55),(1.2,.04,3.95),M['glass'],'15_Entrance',.01)
for x in [-2.1,2.1]:cube('Door_Handle',(x,-14.03,2.15),(.035,.05,.6),M['gold'],'15_Entrance',.01)
curve('Entrance_Canopy_Outer',[(x,-15.2-.7*(1-(x/5)**2),5.2+.8*(1-(x/5)**2)) for x in [-5+i*.1 for i in range(101)]],.13,M['gold'],'15_Entrance')
text('Architectural_Wordmark','THE ZENITH 2100',(0,-14.23,6.36),.73,M['gold'],(math.pi/2,0,0),'80_Wayfinding')
text('Entrance_Subtitle','F U T U R I S T I C   L U X U R Y   D I N I N G',(0,-14.25,5.72),.15,M['light_warm'],(math.pi/2,0,0),'80_Wayfinding')
validate('Stage_01_Architecture')

# Stage 2. True upper-floor ring with atrium opening and a west stairwell cutout.
for quadrant,(start,end) in {'NE':(0,math.pi/2),'NW':(math.pi/2,math.pi),'SW':(math.pi,1.5*math.pi),'SE':(1.5*math.pi,math.tau)}.items():
    n=40;outer=[(21.65*math.cos(start+(end-start)*i/n),13.3*math.sin(start+(end-start)*i/n)) for i in range(n+1)];inner=[(7.2*math.cos(start+(end-start)*i/n),-1+5.5*math.sin(start+(end-start)*i/n)) for i in range(n+1)]
    count=n+1;verts=[(x,y,z) for z in [4.93,5.25] for points in [outer,inner] for x,y in points]
    faces=[]
    for i in range(n):
        j=i+1;faces.extend([(2*count+i,2*count+j,3*count+j,3*count+i),(i,count+i,count+j,j),(i,j,2*count+j,2*count+i),(count+i,3*count+i,3*count+j,count+j)])
    for i in [0,n]:faces.append((i,2*count+i,3*count+i,count+i))
    coll='10_UpperFloor_South' if quadrant in ('SW','SE') else '10_UpperFloor_North'
    obj=mesh('Upper_Atrium_Ring_'+quadrant,verts,faces,M['floor'],coll)
    if quadrant in ('NW','SW'):
        cutter=cube('Temporary_Stairwell_Cutter',(-20.0,-.4,5.1),(3.8,9.1,2),M['black'],'99_Temporary',0)
        bpy.context.view_layer.objects.active=obj;obj.select_set(True)
        mod=obj.modifiers.new('Actual_Stair_Opening','BOOLEAN');mod.operation='DIFFERENCE';mod.solver='EXACT';mod.object=cutter
        bpy.ops.object.modifier_apply(modifier=mod.name);bpy.data.objects.remove(cutter,do_unlink=True);obj.select_set(False)
# Inner atrium balustrades, no rail across stair opening.
for i in range(64):
    t0=math.tau*i/64;t1=math.tau*(i+1)/64
    p0=(7.23*math.cos(t0),-1+5.53*math.sin(t0));p1=(7.23*math.cos(t1),-1+5.53*math.sin(t1))
    mesh(f'Atrium_Balustrade_{i:02}',[(p0[0],p0[1],5.30),(p1[0],p1[1],5.30),(p1[0],p1[1],6.38),(p0[0],p0[1],6.38)],[(0,1,2,3)],M['glass'],'13_Circulation')
curve('Atrium_Gold_Handrail',ellipse(7.23,5.53,6.4,cy=-1),.045,M['gold'],'13_Circulation')
# 27 real treads: riser174mm, going280mm, clearwidth2.7m.
steps=27;rise=(5.25-.55)/steps;going=.28
for i in range(steps):
    y=-4.35+going*(i+.5);top=.55+rise*(i+1)
    cube(f'West_Stair_Tread_{i+1:02}',(-19.98,y,top-.055),(2.65,going+.012,.11),M['stone'],'13_Circulation',.012)
    cube(f'West_Stair_Light_{i+1:02}',(-19.98,y-going/2-.01,top-.06),(2.3,.025,.02),M['light_warm'],'13_Circulation',0)
for x in [-21.32,-18.63]:
    beam('West_Stair_Stringer',(x,-4.35,.48),(x,3.21,5.18),.13,M['titanium'],'13_Circulation')
    beam('West_Stair_Handrail',(x,-4.35,1.55),(x,3.21,6.25),.065,M['gold'],'13_Circulation')
    for i in range(0,steps,3):beam('Stair_Guard_Post',(x,-4.35+going*(i+.5),.55+rise*(i+1)),(x,-4.35+going*(i+.5),1.6+rise*(i+1)),.04,M['gold'],'13_Circulation')
cube('Stair_Upper_Landing',(-19.85,3.8,5.11),(3.0,1.2,.28),M['stone'],'13_Circulation')
# Transparent lift with a clear front opening and aligned landings.
for x in [1.55,4.45]:
    for y in [7.5,10.4]:cube('Elevator_Shaft_Post',(x,y,5.5),(.13,.13,10.0),M['titanium'],'13_Circulation')
for x in [1.62,4.38]:cube('Lift_Side_Glazing',(x,8.95,5.5),(.025,2.8,9.8),M['glass'],'13_Circulation',.005)
cube('Lift_Back_Glazing',(3,10.35,5.5),(2.8,.025,9.8),M['glass'],'13_Circulation',.005)
for z in [.64,5.34]:
    cube('Lift_Level_Sill',(3,7.46,z),(2.75,.3,.08),M['gold'],'13_Circulation',.01)
    cube('Lift_Front_Header',(3,7.48,z+2.5),(2.8,.15,.18),M['titanium'],'13_Circulation')
    text('Lift_Level_Indicator','ZENITH  /  LIFT',(3,7.36,z+2.85),.17,M['light_warm'],(math.pi/2,0,0),'80_Wayfinding')
    cube('Lift_Call_Panel',(4.6,7.40,z+1.1),(.13,.06,.35),M['screen'],'13_Circulation',.02)
from zenith_interiors import build_partitions,build_interiors
build_partitions(M)
validate('Stage_02_Layout_And_Circulation')

# Stage 3. Detailed reusable dining furniture, private rooms and commercial kitchen.
build_interiors(M)
validate('Stage_03_Furniture_And_Technology')

# Stage 4. Gardens, integrated photovoltaics, architectural light and a vertical art piece.
from zenith_landscape import build_landscape
build_landscape(M)
cylinder('Atrium_Water_Rim',(0,-1,.70),2.45,.30,M['gold'],'30_Atrium_Art',64)
cylinder('Atrium_Reflecting_Water',(0,-1,.87),2.29,.028,M['water'],'30_Atrium_Art',64)
for strand,phase in enumerate([0,math.pi]):
    pts=[]
    for i in range(140):
        u=i/139;angle=phase+u*math.pi*2.3;radius=.6+1.1*math.sin(math.pi*u)
        pts.append((radius*math.cos(angle),-1+radius*math.sin(angle),.9+u*6.8))
    curve(f'Zenith_Double_Helix_{strand+1}',pts,.13,M['gold'],'30_Atrium_Art')
curve('Atrium_Chandelier_Frame',ellipse(4.7,3.6,9.4,cy=-1),.09,M['gold'],'40_Architectural_Lighting')
curve('Atrium_Chandelier_Light',ellipse(4.62,3.52,9.32,cy=-1),.045,M['light_warm'],'40_Architectural_Lighting')
for i in range(16):
    t=math.tau*i/16;x=4.7*math.cos(t);y=-1+3.6*math.sin(t)
    beam('Chandelier_Suspension',(x,y,9.4),(x,y,12.3),.012,M['titanium'],'40_Architectural_Lighting')
for side in [-1,1]:
    curve('Integrated_Robot_Route',[(side*4.1,6.5,.568),(side*7.9,3.8,.568),(side*8.1,-3,.568),(side*6.6,-8.0,.568)],.018,M['light_cool'],'31_Robot_Infrastructure')
    for z in [4.65,10.10]:curve('Floor_Edge_Indirect_Lighting',ellipse(20.7,12.6,z,count=100,start=0,end=math.tau),.025,M['light_warm'],'40_Architectural_Lighting')
for side,t0,t1 in [('E',.22,1.38),('W',1.77,2.92)]:
    for j in range(7):
        ta=t0+(t1-t0)*j/7+.012;tb=t0+(t1-t0)*(j+1)/7-.012
        for i in range(2):
            ua=.52+i*.16;ub=ua+.145
            points=[roof_point(ta,ua),roof_point(tb,ua),roof_point(tb,ub),roof_point(ta,ub)]
            points=[(x,y,z+.06) for x,y,z in points]
            mesh(f'Integrated_PV_{side}_{j}_{i}',points,[(0,1,2,3)],M['solar'],'42_Solar_Integration')
            curve('PV_Laminate_Frame',points+[points[0]],.018,M['gold'],'42_Solar_Integration')
            for k in range(1,5):
                v=k/5;p0=Vector(points[0]).lerp(Vector(points[1]),v);p1=Vector(points[3]).lerp(Vector(points[2]),v)
                curve('PV_Cell_Conductor',[p0,p1],.005,M['steel'],'42_Solar_Integration')
# Physically present area sources, not emission-only presentation tricks.
def area(name,loc,target,power,size,color=(1,.82,.64)):
    data=bpy.data.lights.new(name,'AREA');data.energy=power;data.shape='DISK';data.size=size;data.color=color
    obj=bpy.data.objects.new(name,data);collection('41_Light_Sources').objects.link(obj);obj.location=loc;aim(obj,target);return obj
area('Exterior_Key_Softbox',(0,-22,29),(0,0,0),10000,25,(.75,.84,1))
area('Exterior_Warm_Architectural_Fill',(24,-6,18),(0,0,4),6000,18,(1,.80,.55))
area('Exterior_Back_Rim',(-12,18,24),(0,0,4),8500,20,(.72,.85,1))
for x in [-13,13]:
    for y in [-5,4]:area(f'Main_Dining_Ceiling_{x}_{y}',(x,y,4.65),(x,y,.55),750,7)
    for y in [-4,6]:area(f'Upper_Lounge_Ceiling_{x}_{y}',(x,y,10.2),(x,y,5.25),900,7)
area('Atrium_Skylight_Fill',(0,-1,12.9),(0,-1,1),1300,8,(.78,.9,1))
area('Kitchen_Working_Light',(-10,10.1,4.5),(-10,10,.8),1100,9,(.9,.95,1))
for x,y in [(10,7.5),(16,2.5)]:area('Pod_Indirect_Fill',(x,y,8.7),(x,y,5.25),250,3)
world=bpy.data.worlds.new('Zenith | Late afternoon architectural sky');world.use_nodes=True;scene.world=world
nodes=world.node_tree.nodes;links=world.node_tree.links;bg=nodes.get('Background');bg.inputs['Strength'].default_value=.28
sky=nodes.new('ShaderNodeTexSky');sky.sky_type='NISHITA';sky.sun_elevation=math.radians(19);sky.sun_rotation=math.radians(135);sky.sun_disc=True;sky.sun_intensity=.65;sky.air_density=1.2;links.new(sky.outputs[0],bg.inputs[0])
validate('Stage_04_Materials_Light_And_Landscape')

# Stage 5. Independent cameras and named presentation view layers.
CAMERAS=[
 ('01_Hero_Exterior',(48,-57,29),(0,-1,4.7),46,None,'Exterior'),
 ('02_Aerial_Cutaway',(39,-43,52),(0,0,2.7),46,72,'Cutaway'),
 ('03_Front_Elevation',(0,-65,10),(0,0,5.3),50,66,'Exterior'),
 ('04_East_Elevation',(65,-1,11),(0,0,5.4),50,60,'Exterior'),
 ('05_Main_Dining',(-3,-10.8,2.2),(-12.3,1.2,1.8),23,None,'Exterior'),
 ('06_Kitchen_And_Service',(-8.8,6.5,2.25),(-11.2,10.5,1.8),21,None,'Exterior'),
 ('07_Private_Dining',(17,-4.9,7.1),(10.2,7.5,6.8),27,None,'Exterior'),
 ('08_Smart_Table_Detail',(7.6,-9.5,2.10),(10.5,-6,1.35),43,None,'Exterior'),
 ('09_Material_And_Roof_Detail',(33,-15,17.4),(19,-4,9),58,None,'Exterior')
]
camera_manifest=[]
for name,loc,target,lens,ortho,layer in CAMERAS:
    data=bpy.data.cameras.new(name);data.lens=lens;data.clip_start=.05;data.clip_end=350
    obj=bpy.data.objects.new(name,data);collection('70_Presentation_Cameras').objects.link(obj);obj.location=loc;aim(obj,target)
    if ortho:data.type='ORTHO';data.ortho_scale=ortho
    obj['presentation_layer']=layer;obj['view_description']=name.replace('_',' ')
    camera_manifest.append({'name':name,'location':loc,'target':target,'lens_mm':lens,'ortho_scale_m':ortho,'view_layer':layer,'output':f'renders/{name}.png'})
scene.camera=bpy.data.objects['01_Hero_Exterior']
base=scene.view_layers[0];base.name='Exterior'
cutaway=scene.view_layers.new('Cutaway')
for name in ['12_Roof','14_Oculus_Glass','10_UpperFloor_South','11_Glass_South']:
    child=cutaway.layer_collection.children.get(name)
    if child:child.exclude=True
for layer in scene.view_layers:layer.use=layer.name=='Exterior'
scene.render.engine='CYCLES';scene.cycles.device='CPU';scene.cycles.use_denoising=False;scene.cycles.samples=96;scene.cycles.use_adaptive_sampling=True;scene.cycles.adaptive_threshold=.025
scene.cycles.max_bounces=6;scene.cycles.diffuse_bounces=3;scene.cycles.glossy_bounces=3;scene.cycles.transmission_bounces=6;scene.cycles.transparent_max_bounces=8
scene.cycles.caustics_reflective=False;scene.cycles.caustics_refractive=False;scene.cycles.sample_clamp_indirect=5
scene.render.threads_mode='FIXED';scene.render.threads=5
scene.render.resolution_x=1600;scene.render.resolution_y=1200;scene.render.resolution_percentage=100
scene.render.image_settings.file_format='PNG';scene.render.image_settings.color_mode='RGB';scene.render.image_settings.color_depth='8'
scene.view_settings.view_transform='AgX';scene.view_settings.look='AgX - Medium High Contrast';scene.view_settings.exposure=.15
scene.render.film_transparent=False
scene['Laptop_preview']='Use Solid or Material Preview. Render presets are in scripts/render_zenith.py; geometry and camera objects remain separate.'
scene['Denoiser_note']='This installed Blender build has no OpenImageDenoise; denoising is intentionally disabled.'
scene['Interior_seats']=scene.get('indoor_seating_capacity',0)
(ROOT/'cameras'/'camera_manifest.json').write_text(json.dumps(camera_manifest,indent=2))
validate('Stage_05_Cameras_And_Render_Settings')
# A useful opening viewport in interactive Blender.
for screen in bpy.data.screens:
    for space in [area.spaces.active for area in screen.areas if area.type=='VIEW_3D']:
        space.clip_end=500;space.shading.type='MATERIAL';space.overlay.show_floor=False
# Save canonical original; checkpoints remain optional intermediate review files.
bpy.ops.wm.save_as_mainfile(filepath=str(ROOT/'Zenith2100.blend'))
print('ZENITH_BUILD_COMPLETE',str(ROOT/'Zenith2100.blend'),len(scene.objects),flush=True)
