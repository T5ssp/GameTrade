"""Atomically save a resumable project status and a compact work backup.
No third-party binary or raw render is required to open the archived .blend.
"""
from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
import json,os,hashlib,zipfile,struct
ROOT=Path(__file__).resolve().parents[1]

def _save_checkpoint():
    cameras=json.loads((ROOT/'cameras/camera_manifest.json').read_text())
    try:rows=json.loads((ROOT/'logs/presentation_presentation.json').read_text())
    except (OSError,ValueError):rows=[]
    completed=[]
    for row in rows:
        p=ROOT/row.get('file','missing')
        if row.get('verified') and p.is_file() and p.stat().st_size>10000:
            completed.append(row)
    remaining=[c['name'] for c in cameras if c['name'] not in {r['camera'] for r in completed}]
    stamp=datetime.now(ZoneInfo('Asia/Dubai')).isoformat(timespec='seconds')
    state={'updated_dubai':stamp,'project_root':str(ROOT),'native_file':'Zenith2100.blend','native_sha256':hashlib.sha256((ROOT/'Zenith2100.blend').read_bytes()).hexdigest(),'completed_cameras':[r['camera'] for r in completed],'remaining_cameras':remaining,'blender_version':'4.3.2','render_pipeline':'Cycles CPU + verified official Intel OIDN2.5.1','native_model_reopened_and_tested':True,'circulation_ray_tests_passed':True,'user_approved_oidn_install':True,'oidn_sha256':'743c3e2aff8c220d5d70fe6cb970fb3d36f2702d2693c61d1d148e404cf37cd6','render_command':'blender -b Zenith2100.blend --threads 5 --python scripts/render_presentation.py -- --shots all --profile presentation','final_package_command':'python3 scripts/package_delivery.py','note':'All custom source and generated output files are saved in the project folder. Running processes may not survive an environment shutdown; continue from saved files.'}
    state_path=ROOT/'PROJECT_STATE.json';tmp=state_path.with_suffix('.json.tmp');tmp.write_text(json.dumps(state,indent=2));os.replace(tmp,state_path)
    done_list=''.join('- `'+r['file']+'`\n' for r in completed)
    pending_list=''.join('- `'+name+'`\n' for name in remaining) or '- لا شيء.\n'
    text=f"""# متابعة مشروع The Zenith 2100

آخر حفظ بتوقيت دبي: {stamp}

## ما هو محفوظ بالفعل

- المشروع الأصلي: `Zenith2100.blend`، مجسم حقيقي قابل للتعديل.
- الفكرة: مطعم فاخر بجناحين سقفيين حول بهو مركزي، ومستويين، و96 مقعدًا: 72 داخليًا و24 خارجيًا.
- نحو 33 Collection و9 كاميرات، مع خامات PBR إجرائية دون صور خامات خارجية مفقودة.
- أعيد فتح الملف في Blender. اختبارات فتحات المصعد والسلم ودعم البسطة والغرفة الخاصة محفوظة في `logs/final_file_validation.json`.
- السكربتات والوثائق وOBJ/MTL محفوظة. لا حاجة لإعادة بناء المجسم لاستكمال الصور.
- وافق المستخدم على أداة Intel OIDN الرسمية داخل `tools` فقط، وفُحصت بصمتها وشُغّلت فعليًا. تنزيل نسخة Blender المحمولة حُجب بالشبكة ولم تُثبَّت؛ استُخدم Blender المتوفر مع أداة التنقية المعتمدة.

## الصور

المكتمل: **{len(completed)} من 9**.

{done_list}
المتبقي:

{pending_list}
## الاستكمال إذا انقطعت الجلسة

1. ابدأ من مجلد المشروع واقرأ `PROJECT_STATE.json` و`logs/presentation_presentation.json`.
2. تحقق أولًا من توقف الرندر السابق؛ لا تشغّل نسختين منه بالتوازي على الأنوية نفسها.
3. إذا توقف، نفّذ الأمر التالي. السكربت يحافظ على الصور المكتملة الموثقة بعد فحص سلامة PNG، ويعيد إنتاج أي صورة ناقصة أو تالفة:

```sh
blender -b Zenith2100.blend --threads 5 --python scripts/render_presentation.py -- --shots all --profile presentation
```

4. راجع الصور بصريًا، خصوصًا الغرف الخاصة والطاولة الذكية وتفاصيل الخامات.
5. بعد اكتمال التسع شغّل:

```sh
blender -b Zenith2100.blend --threads 1 --python scripts/verify_zenith.py -- --export-obj
python3 scripts/package_delivery.py
```

6. الناتج النهائي: `The_Zenith_2100_Deliverables.zip` ومعرض `renders/gallery.html`. النسخة `Zenith2100_Checkpoint.zip` حزمة حفظ مرحلية، وقد تشمل صورًا جزئية حتى انتهاء الدفعة.

## الحفظ المستمر

- المصدر والمجسم والصور محفوظة داخل مجلد المشروع؛ لا تعتمد المتابعة على ذاكرة المحادثة.
- `scripts/watch_checkpoint.py` يجدد سجل الحالة والنسخة المضغوطة بعد الصور أو تغير المصدر.
- يمكن تحديث الحفظ يدويًا: `python3 scripts/save_checkpoint.py`.
- لا يمكن ضمان استمرار عملية الرندر بعد إيقاف البيئة، لكن الملفات المكتملة قابلة للاستكمال.
- لا تدّعِ نجاح صور لم تُنتج. لا تثبّت برامج إضافية أو تصل إلى ملفات شخصية خارج المشروع دون موافقة المستخدم.
- أذن المستخدم بتسليم حزمة المشروع عبر مستودع T5ssp/GameTrade داخل architecture/The_Zenith_2100، مع إبقاء ملفات الموقع منفصلة.
"""
    progress=ROOT/'PROJECT_STATE.md';tmp=progress.with_suffix('.md.tmp');tmp.write_text(text);os.replace(tmp,progress)
    include=[ROOT/'Zenith2100.blend',ROOT/'README.md',ROOT/'AGENTS.md',state_path,progress]
    for folder,pattern in [('scripts','*.py'),('docs','*'),('cameras','*.json'),('exports','*')]:
        include.extend(p for p in (ROOT/folder).glob(pattern) if p.is_file())
    include += [ROOT/r['file'] for r in completed]
    include += [ROOT/'logs'/name for name in ['final_file_validation.json','circulation_geometry.json','build_validation.json','oidn_installation.json','presentation_presentation.json'] if (ROOT/'logs'/name).is_file()]
    archive=ROOT/'Zenith2100_Checkpoint.zip';temporary=archive.with_suffix('.zip.tmp')
    with zipfile.ZipFile(temporary,'w',zipfile.ZIP_DEFLATED,compresslevel=3) as z:
        for path in include:z.write(path,'The_Zenith_2100/'+str(path.relative_to(ROOT)))
        z.writestr('The_Zenith_2100/CHECKPOINT_NOTE.txt','Work-in-progress backup. See PROJECT_STATE.md. Raw EXR/PFM files, intermediate .blend checkpoints, downloaded archives and optional Linux denoiser binaries remain saved in the project folder but are omitted from this compact ZIP. Native .blend needs no external textures or plugins to open.\n')
    with zipfile.ZipFile(temporary) as z:assert z.testzip() is None
    os.replace(temporary,archive)
    return state

def save_checkpoint():
    # Process-level locking prevents manual and automatic saves sharing a temp ZIP.
    lock_path=ROOT/'logs/checkpoint.lock'
    with lock_path.open('a+b') as lock:
        if os.name=='posix':
            import fcntl
            fcntl.flock(lock.fileno(),fcntl.LOCK_EX)
        else:
            import msvcrt
            if lock.seek(0,2)==0:lock.write(b'0');lock.flush()
            lock.seek(0);msvcrt.locking(lock.fileno(),msvcrt.LK_LOCK,1)
        try:return _save_checkpoint()
        finally:
            if os.name=='posix':fcntl.flock(lock.fileno(),fcntl.LOCK_UN)
            else:lock.seek(0);msvcrt.locking(lock.fileno(),msvcrt.LK_UNLCK,1)

if __name__=='__main__':
    state=save_checkpoint();print('Checkpoint saved:',len(state['completed_cameras']),'of9renders;',ROOT/'Zenith2100_Checkpoint.zip')
