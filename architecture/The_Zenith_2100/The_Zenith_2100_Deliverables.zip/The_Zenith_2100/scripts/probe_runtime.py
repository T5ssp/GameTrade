import bpy,json,sys,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
bpy.ops.wm.read_factory_settings(use_empty=True)
bpy.ops.mesh.primitive_cube_add(location=(0,0,1))
bpy.ops.object.camera_add(location=(5,-7,5));cam=bpy.context.object
from mathutils import Vector
cam.rotation_euler=(Vector((0,0,1))-cam.location).to_track_quat('-Z','Y').to_euler()
bpy.context.scene.camera=cam
bpy.ops.object.light_add(type='AREA',location=(0,-3,6));bpy.context.object.data.energy=800;bpy.context.object.data.shape='DISK';bpy.context.object.data.size=5
s=bpy.context.scene;s.render.engine='CYCLES';s.cycles.device='CPU';s.cycles.samples=16;s.cycles.use_denoising=False;s.render.threads_mode='FIXED';s.render.threads=5;s.render.resolution_x=192;s.render.resolution_y=128;s.render.resolution_percentage=100;s.render.filepath=str(ROOT/'logs'/'runtime_probe.png')
t=time.time();bpy.ops.render.render(write_still=True)
report={'blender':bpy.app.version_string,'cycles_cpu_render':True,'seconds':time.time()-t,'threads':5,'gpu_available':False,'image':s.render.filepath}
(ROOT/'logs'/'runtime_probe.json').write_text(json.dumps(report,indent=2))
print('ZENITH_RUNTIME_PROBE',json.dumps(report))
try:
 s.render.engine='BLENDER_EEVEE_NEXT';s.render.filepath=str(ROOT/'logs'/'runtime_probe_eevee.png');t=time.time();bpy.ops.render.render(write_still=True);report['eevee_render']=True;report['eevee_seconds']=time.time()-t
except Exception as error:
 report['eevee_render']=False;report['eevee_error']=str(error)
(ROOT/'logs'/'runtime_probe.json').write_text(json.dumps(report,indent=2))

