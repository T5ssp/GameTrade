"""Render named, independently editable presentation cameras.
blender -b Zenith2100.blend --threads 5 --python scripts/render_zenith.py -- --shots 01,05 --quality draft
Quality: draft (800x600/24), standard (1600x1200/96), final (1800x1350/192).
"""
import bpy,json,sys,time,argparse,math
from array import array
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
args=sys.argv[sys.argv.index('--')+1:] if '--' in sys.argv else []
p=argparse.ArgumentParser();p.add_argument('--shots',default='all');p.add_argument('--quality',choices=['draft','standard','final'],default='standard');p.add_argument('--overwrite',action='store_true');cfg=p.parse_args(args)
scene=bpy.context.scene
width,height,samples={'draft':(800,600,24),'standard':(1600,1200,96),'final':(1800,1350,192)}[cfg.quality]
scene.render.engine='CYCLES';scene.cycles.device='CPU';scene.cycles.use_denoising=False;scene.cycles.samples=samples
scene.render.resolution_x=width;scene.render.resolution_y=height;scene.render.resolution_percentage=100
scene.render.threads_mode='FIXED';scene.render.threads=5
manifest=json.loads((ROOT/'cameras'/'camera_manifest.json').read_text())
chosen=manifest if cfg.shots=='all' else [camera for camera in manifest if camera['name'][:2] in cfg.shots.split(',') or camera['name'] in cfg.shots.split(',')]
if not chosen:raise RuntimeError('No matching cameras selected.')
report_path=ROOT/'logs'/f'render_{cfg.quality}.json'
previous=json.loads(report_path.read_text()) if report_path.exists() else []
for camera in chosen:
    output=ROOT/('renders/drafts' if cfg.quality=='draft' else 'renders')/(camera['name']+'.png');output.parent.mkdir(exist_ok=True,parents=True)
    if output.exists() and not cfg.overwrite:
        print('ZENITH_EXISTING_RENDER_SKIP',camera['name'],flush=True);continue
    scene.camera=bpy.data.objects[camera['name']]
    for layer in scene.view_layers:layer.use=layer.name==camera['view_layer']
    scene.render.filepath=str(output);started=time.time()
    print('ZENITH_RENDER_START',camera['name'],cfg.quality,flush=True)
    bpy.ops.render.render(write_still=True,layer=camera['view_layer'])
    if not output.exists() or output.stat().st_size<10000:raise RuntimeError('Missing or empty render: '+str(output))
    image=bpy.data.images.load(str(output),check_existing=False)
    if tuple(image.size)!=(width,height):raise RuntimeError('Unexpected render dimensions.')
    pixels=array('f',[0])*len(image.pixels);image.pixels.foreach_get(pixels);stride=max(4,len(pixels)//2048//4*4);sample=pixels[::stride]
    if max(sample)-min(sample)<.01:raise RuntimeError('Render appears blank: '+camera['name'])
    bpy.data.images.remove(image)
    record={'camera':camera['name'],'quality':cfg.quality,'engine':'Cycles CPU','samples':samples,'dimensions':[width,height],'seconds':round(time.time()-started,2),'file':str(output.relative_to(ROOT)),'bytes':output.stat().st_size,'image_verified':True}
    previous=[entry for entry in previous if entry['camera']!=camera['name']]+[record];report_path.write_text(json.dumps(previous,indent=2))
    print('ZENITH_RENDER_OK',json.dumps(record),flush=True)
