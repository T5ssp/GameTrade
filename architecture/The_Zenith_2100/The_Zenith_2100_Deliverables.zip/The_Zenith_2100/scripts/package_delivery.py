"""Validate completed deliverables and build a portable project archive.
Run only after the nine presentation renders and Blender reopening audit succeed.
"""
from pathlib import Path
import json,struct,hashlib,zipfile,html
ROOT=Path(__file__).resolve().parents[1]
report=json.loads((ROOT/'logs/final_file_validation.json').read_text())
assert report['passed'] and not report['errors'],'Native Blender reopening audit did not pass.'
assert all(c['passed'] for c in report['circulation_geometry'].values()),'Circulation checks failed'
manifest=json.loads((ROOT/'cameras/camera_manifest.json').read_text())
renders=json.loads((ROOT/'logs/presentation_presentation.json').read_text())
by_camera={entry['camera']:entry for entry in renders}
images=[]
for shot in manifest:
    name=shot['name'];path=ROOT/'renders'/(name+'.png')
    assert name in by_camera and by_camera[name]['verified'],'Missing completed render record: '+name
    data=path.read_bytes();assert data[:8]==b'\x89PNG\r\n\x1a\n'
    width,height=struct.unpack('>II',data[16:24]);assert (width,height)==tuple(by_camera[name]['dimensions'])
    assert path.stat().st_mtime>=(ROOT/'Zenith2100.blend').stat().st_mtime,'Render predates the saved final scene: '+name
    images.append({'camera':name,'path':str(path.relative_to(ROOT)),'dimensions':[width,height],'sha256':hashlib.sha256(data).hexdigest()})
blend=ROOT/'Zenith2100.blend';assert blend.read_bytes()[:7]==b'BLENDER'
obj=ROOT/'exports/Zenith2100.obj';counts={'vertices':0,'faces':0,'objects':0}
with obj.open() as stream:
    for line in stream:
        if line.startswith('v '):counts['vertices']+=1
        elif line.startswith('f '):counts['faces']+=1
        elif line.startswith('o '):counts['objects']+=1
assert counts['faces']>10000 and counts['objects']>100,'OBJ lacks model geometry'
labels={
 '01':'Hero exterior','02':'Aerial architectural cutaway','03':'Front architectural elevation','04':'East architectural elevation',
 '05':'Main dining hall','06':'Professional kitchen','07':'Private dining suites','08':'Smart table and holographic menu','09':'Titanium roof and glass facade detail'}
cards=''.join(f'<article><a href="{html.escape(Path(i["path"]).name)}"><img src="{html.escape(Path(i["path"]).name)}" loading="lazy" alt="{labels[i["camera"][:2]]}"></a><h2>{labels[i["camera"][:2]]}</h2><p>{i["dimensions"][0]} × {i["dimensions"][1]} · Cycles / OIDN</p></article>' for i in images)
cards += '<article style="grid-column:1/-1"><a href="../docs/CONCEPT_PLANS.svg"><img src="../docs/CONCEPT_PLANS.png" alt="Ground and upper concept plans"></a><h2>Spatial organization · Ground and upper levels</h2><p>Concept plan sheet · Actual model coordinates · Not a construction drawing</p></article>'
gallery='''<!doctype html><html lang="en"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>The Zenith 2100 | Architectural presentation</title><style>body{margin:0;background:#0c1d27;color:#e7e8e2;font:14px Arial,sans-serif}header{max-width:1400px;margin:auto;padding:60px 5% 35px;border-bottom:1px solid #52636b}h1{font:42px Georgia,serif;font-weight:400;margin:10px 0;color:#dec397}.eyebrow{letter-spacing:4px;font-size:11px;color:#8eb5c8}main{max-width:1400px;margin:auto;padding:30px 5%;display:grid;grid-template-columns:1fr 1fr;gap:30px}article{margin:0;background:#132b38;padding:12px;border:1px solid #314b59;border-radius:8px}article:first-child{grid-column:1/-1}img{display:block;width:100%;height:auto;border-radius:4px}h2{font-size:16px;font-weight:400;margin:18px 5px 5px}p{color:#aac0cb;line-height:1.8;margin:5px}a{color:#dec397}footer{padding:30px 5%;text-align:center;color:#8ca6b5}@media(max-width:700px){main{grid-template-columns:1fr}h1{font-size:32px}}</style><header><div class="eyebrow">ARCHITECTURAL CONCEPT · YEAR 2100</div><h1>The Zenith 2100</h1><p>Futuristic Luxury Restaurant · Editable Blender architecture · 96 concept seats · Two levels around a daylit atrium</p><p><a href="../Zenith2100.blend">Original Blender project</a> · <a href="../docs/DESIGN_CONCEPT.md">Design narrative</a></p></header><main>'''+cards+'''</main><footer>Original 3D scene rendered with Cycles CPU. Procedural PBR materials. No image-generation alteration. University concept; further statutory and engineering development required.</footer></html>'''
(ROOT/'renders/gallery.html').write_text(gallery)
delivery={'blender_file':'Zenith2100.blend','blend_sha256':hashlib.sha256(blend.read_bytes()).hexdigest(),'native_reopen_passed':True,'circulation_geometry_passed':True,'images':images,'obj_geometry':counts,'scope':'Editable architectural university concept, not execution-certified documents','images_from_final_scene':True}
(ROOT/'logs/delivery_manifest.json').write_text(json.dumps(delivery,indent=2))
include=[blend,ROOT/'README.md',ROOT/'AGENTS.md',ROOT/'PROJECT_STATE.md',ROOT/'PROJECT_STATE.json',ROOT/'renders/gallery.html',ROOT/'exports/Zenith2100.obj',ROOT/'exports/Zenith2100.mtl']
include += sorted((ROOT/'scripts').glob('*.py'))+sorted((ROOT/'docs').glob('*'))+sorted((ROOT/'cameras').glob('*.json'))
include += [ROOT/i['path'] for i in images]
include += [ROOT/'logs'/name for name in ['runtime_probe.json','oidn_installation.json','build_validation.json','circulation_geometry.json','final_file_validation.json','presentation_presentation.json','delivery_manifest.json']]
archive=ROOT/'The_Zenith_2100_Deliverables.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
    for path in include:
        assert path.is_file(),str(path)
        z.write(path,'The_Zenith_2100/'+str(path.relative_to(ROOT)))
    z.writestr('The_Zenith_2100/ARCHIVE_CONTENTS.txt','This archive includes the original editable .blend, OBJ/MTL, nine finished renders, gallery, source scripts, design documents and validation reports.\nLarge raw renders, old checkpoints and Linux-only third-party binaries are omitted. They are optional for opening or editing the native Blender project. See README for render alternatives.\n')
with zipfile.ZipFile(archive) as z:assert z.testzip() is None
print(json.dumps({'archive':str(archive),'bytes':archive.stat().st_size,'renders_verified':len(images),'obj_geometry':counts,'native_file_verified':True},indent=2))
