"""Editable metre-scale Blender components for The Zenith 2100."""
import bpy, math, bmesh
from mathutils import Vector

def collection(name):
    found=bpy.data.collections.get(name)
    if found:return found
    found=bpy.data.collections.new(name);bpy.context.scene.collection.children.link(found);return found

def link_object(obj,name):
    target=collection(name)
    for old in list(obj.users_collection):old.objects.unlink(obj)
    target.objects.link(obj)
    return obj

def material_on(obj,mat):
    if mat is not None:obj.data.materials.append(mat)
    return obj

def mesh(name,verts,faces,mat=None,collection='10_Architecture'):
    data=bpy.data.meshes.new(name+'_Mesh');data.from_pydata(verts,[],faces);data.update()
    bm=bmesh.new();bm.from_mesh(data);bmesh.ops.recalc_face_normals(bm,faces=list(bm.faces));bm.to_mesh(data);bm.free();data.update()
    obj=bpy.data.objects.new(name,data)
    globals()['collection'](collection).objects.link(obj);material_on(obj,mat)
    return obj

def cube(name,loc,size,mat=None,collection='10_Architecture',bevel=.03):
    x,y,z=[v/2 for v in size]
    verts=[(-x,-y,-z),(-x,-y,z),(-x,y,-z),(-x,y,z),(x,-y,-z),(x,-y,z),(x,y,-z),(x,y,z)]
    faces=[(0,4,6,2),(1,3,7,5),(0,1,5,4),(2,6,7,3),(0,2,3,1),(4,5,7,6)]
    obj=mesh(name,verts,faces,mat,collection);obj.location=loc
    if bevel and min(size)>bevel*2:
        mod=obj.modifiers.new('Architectural_Edge_Radius','BEVEL');mod.width=bevel;mod.segments=2
        mod=obj.modifiers.new('Weighted_Surface_Normals','WEIGHTED_NORMAL')
    return obj

def cylinder(name,loc,radius,depth,mat=None,collection='10_Architecture',vertices=32):
    points=[(radius*math.cos(2*math.pi*i/vertices),radius*math.sin(2*math.pi*i/vertices),-depth/2) for i in range(vertices)]
    points += [(x,y,depth/2) for x,y,_ in points]
    faces=[tuple(range(vertices-1,-1,-1)),tuple(range(vertices,2*vertices))]
    faces += [(i,(i+1)%vertices,(i+1)%vertices+vertices,i+vertices) for i in range(vertices)]
    obj=mesh(name,points,faces,mat,collection);obj.location=loc
    for poly in obj.data.polygons[2:]:poly.use_smooth=True
    return obj

def sphere(name,loc,scale,mat=None,collection='10_Architecture',segments=16,rings=8):
    verts=[(0,0,scale[2])]
    for j in range(1,rings):
        phi=math.pi*j/rings
        for i in range(segments):
            theta=2*math.pi*i/segments
            verts.append((scale[0]*math.sin(phi)*math.cos(theta),scale[1]*math.sin(phi)*math.sin(theta),scale[2]*math.cos(phi)))
    bottom=len(verts);verts.append((0,0,-scale[2]));faces=[]
    for i in range(segments):faces.append((0,1+i,1+(i+1)%segments))
    for j in range(rings-2):
        for i in range(segments):
            a=1+j*segments+i;b=1+j*segments+(i+1)%segments
            faces.append((a,a+segments,b+segments,b))
    start=1+(rings-2)*segments
    for i in range(segments):faces.append((start+i,bottom,start+(i+1)%segments))
    obj=mesh(name,verts,faces,mat,collection);obj.location=loc
    for face in obj.data.polygons:face.use_smooth=True
    return obj

def curve(name,points,radius,mat=None,collection='10_Architecture',cyclic=False):
    data=bpy.data.curves.new(name+'_Curve','CURVE');data.dimensions='3D';data.resolution_u=2;data.bevel_depth=radius;data.bevel_resolution=2
    spline=data.splines.new('POLY');spline.points.add(len(points)-1)
    for p,co in zip(spline.points,points):p.co=(*co,1)
    spline.use_cyclic_u=cyclic
    obj=bpy.data.objects.new(name,data);globals()['collection'](collection).objects.link(obj);material_on(obj,mat);return obj

def text(name,body,loc,size,mat=None,rotation=(0,0,0),collection='80_Wayfinding'):
    data=bpy.data.curves.new(name+'_Typography','FONT');data.body=body;data.size=size;data.align_x='CENTER';data.align_y='CENTER';data.extrude=.007;data.bevel_depth=.002;data.space_character=1.13
    obj=bpy.data.objects.new(name,data);globals()['collection'](collection).objects.link(obj);obj.location=loc;obj.rotation_euler=rotation;material_on(obj,mat);return obj

def aim(obj,target):obj.rotation_euler=(Vector(target)-obj.location).to_track_quat('-Z','Y').to_euler()

def beam(name,start,end,width,mat,collection='10_Architecture'):
    middle=(Vector(start)+Vector(end))/2;length=(Vector(end)-Vector(start)).length
    obj=cube(name,middle,(width,width,length),mat,collection,bevel=width*.16)
    obj.rotation_euler=(Vector(end)-Vector(start)).to_track_quat('Z','Y').to_euler();return obj

def ellipse(a,b,z=0,cx=0,cy=0,count=128,start=0,end=math.tau):
    return [(cx+a*math.cos(start+(end-start)*i/count),cy+b*math.sin(start+(end-start)*i/count),z) for i in range(count+1)]

def ring_slab(name,outer,inner,z,depth,mat,collection='10_Architecture'):
    n=len(outer);verts=[(x,y,z-depth) for x,y in outer]+[(x,y,z-depth) for x,y in inner]+[(x,y,z) for x,y in outer]+[(x,y,z) for x,y in inner]
    faces=[]
    for i in range(n):
        j=(i+1)%n
        faces.extend([(2*n+i,2*n+j,3*n+j,3*n+i),(i,n+i,n+j,j),(i,j,2*n+j,2*n+i),(n+i,3*n+i,3*n+j,n+j)])
    return mesh(name,verts,faces,mat,collection)

def slab(name,points,z,depth,mat,collection='10_Architecture'):
    n=len(points);verts=[(x,y,z-depth) for x,y in points]+[(x,y,z) for x,y in points]
    faces=[tuple(range(n-1,-1,-1)),tuple(range(n,2*n))]
    faces += [(i,(i+1)%n,(i+1)%n+n,i+n) for i in range(n)]
    return mesh(name,verts,faces,mat,collection)
