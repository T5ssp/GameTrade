"""Finalize cutaway visibility, lightweight opening viewport and project metadata."""
import bpy,json
from pathlib import Path
from mathutils import Vector
ROOT=Path(__file__).resolve().parents[1]
scene=bpy.context.scene
bpy.data.objects['Continuous_Context_Plane'].scale.x=12
bpy.data.objects['Continuous_Context_Plane'].scale.y=12
# Cutaway keeps actual front mezzanine furnishings together with its hidden slab.
source=bpy.data.collections.get('32_Mezzanine_Dining')
target=bpy.data.collections.get('32_Mezzanine_South_Cutaway')
if target is None:target=bpy.data.collections.new('32_Mezzanine_South_Cutaway');scene.collection.children.link(target)
bpy.context.view_layer.update()
if source:
 for obj in list(source.objects):
  center=sum((obj.matrix_world@Vector(corner) for corner in obj.bound_box),Vector())/8 if obj.type in ('MESH','CURVE','FONT') else obj.location
  if center.y<0:
   source.objects.unlink(obj);target.objects.link(obj)
cut=scene.view_layers.get('Cutaway')
for name in ['12_Roof','14_Oculus_Glass','14_Oculus_Frame','42_Solar_Integration','10_UpperFloor_South','11_Glass_South','32_Mezzanine_South_Cutaway']:
 child=cut.layer_collection.children.get(name)
 if child:child.exclude=True
scene['Outdoor_seats']=24;scene['Total_concept_seats']=96
scene['Image_pipeline']='Cycles CPU; official Intel Open Image Denoise2.5.1 outside Blender only for image noise removal; AgX color management.'
scene['Denoiser_integrity']='SHA256743c3e2aff8c220d5d70fe6cb970fb3d36f2702d2693c61d1d148e404cf37cd6'
scene['Quality_note']='Glass uses editable transparent shadow-ray approximation for CPU efficiency; concept not a structural or energy-performance simulation.'
scene.cycles.samples=96;scene.cycles.use_denoising=False
scene.camera=bpy.data.objects['01_Hero_Exterior'];scene.use_nodes=False
for layer in scene.view_layers:layer.use=layer.name=='Exterior'
for screen in bpy.data.screens:
 for area in screen.areas:
  if area.type=='VIEW_3D':
   space=area.spaces.active;space.shading.type='SOLID';space.shading.color_type='MATERIAL';space.shading.light='STUDIO';space.overlay.show_floor=False;space.clip_end=5000
   if space.region_3d:space.region_3d.view_perspective='CAMERA'
for obj in bpy.context.selected_objects:obj.select_set(False)
bpy.context.view_layer.objects.active=scene.camera
bpy.ops.wm.save_as_mainfile(filepath=str(ROOT/'Zenith2100.blend'))
print('ZENITH_FINAL_SCENE_SAVED',len(scene.objects),flush=True)
