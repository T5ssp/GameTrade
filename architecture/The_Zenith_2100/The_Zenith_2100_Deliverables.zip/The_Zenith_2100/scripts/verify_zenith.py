"""Reopen and audit the saved Blender model; optionally export actual OBJ geometry."""
import bpy,json,math,sys
from mathutils import Vector
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
scene=bpy.context.scene
errors=[]
for obj in scene.objects:
    if not all(math.isfinite(value) for row in obj.matrix_world for value in row):errors.append('Non-finite transform '+obj.name)
    if obj.type=='MESH' and (not obj.data.polygons or not obj.data.materials):errors.append('Incomplete mesh '+obj.name)
cameras=[obj.name for obj in scene.objects if obj.type=='CAMERA']
if len(cameras)<9:errors.append('Missing presentation cameras')
if not bpy.data.objects.get('Roof_East_Sculpted_Petal') or not bpy.data.objects.get('Roof_West_Sculpted_Petal'):errors.append('Split-petal roofs missing')
steps=[obj for obj in scene.objects if obj.name.startswith('West_Stair_Tread_')]
if len(steps)!=27:errors.append('Incorrect stair step count')
if abs(scene['Upper_FFL_m']-scene['Ground_FFL_m']-4.7)>.001:errors.append('Floor-level alignment failed')
if scene.get('indoor_seating_capacity')!=72:errors.append('Indoor seat count is not72')
missing=[image.filepath for image in bpy.data.images if image.source=='FILE' and not image.packed_file and image.filepath and not Path(bpy.path.abspath(image.filepath)).exists()]
if missing:errors.append('Missing texture files')
circulation={}
for label,point,expected in [('lift_shaft',(3,8.95,6),False),('stairwell',(-19.6,-.4,6),False),('stair_landing',(-19,3.8,6),True),('private_suite_floor',(10,7.5,6),True)]:
    hits=[]
    for obj in scene.objects:
        if obj.type=='MESH' and (obj.name.startswith('Upper_Atrium_Ring_') or obj.name=='Stair_Upper_Landing'):
            hit,location,normal,index=obj.ray_cast(obj.matrix_world.inverted()@Vector(point),Vector((0,0,-1)),distance=1.5)
            if hit:hits.append(obj.name)
    circulation[label]={'expected_floor':expected,'floor_hits':hits,'passed':bool(hits)==expected}
    if bool(hits)!=expected:errors.append('Circulation geometry failed: '+label)
floor_areas={}
for obj in scene.objects:
    if obj.type=='MESH' and (obj.name.startswith('Upper_Atrium_Ring_') or obj.name=='Ground_Organic_Plinth'):
        floor_areas[obj.name]=round(sum(poly.area for poly in obj.data.polygons if poly.normal.z>.9),2)
report={'circulation_geometry':circulation,'floor_top_surface_areas_m2':floor_areas,'reopened_file':str(ROOT/'Zenith2100.blend'),'blender_version':bpy.app.version_string,'objects':len(scene.objects),'mesh_objects':sum(obj.type=='MESH' for obj in scene.objects),'materials':len(bpy.data.materials),'collections':len(bpy.data.collections),'unique_meshes':len(bpy.data.meshes),'cameras':cameras,'floor_levels_m':[scene['Ground_FFL_m'],scene['Upper_FFL_m']],'indoor_seats':scene.get('indoor_seating_capacity'),'steps':len(steps),'external_texture_dependencies':missing,'procedural_materials':True,'errors':errors,'passed':not errors}
if '--export-obj' in sys.argv:
    # Native .blend keeps all editability; OBJ is an optional geometry interchange copy.
    bpy.ops.object.select_all(action='DESELECT')
    for obj in scene.objects:
        if obj.type in ('MESH','CURVE','FONT') and obj.name!='Continuous_Context_Plane':obj.select_set(True)
    bpy.ops.wm.obj_export(filepath=str(ROOT/'exports'/'Zenith2100.obj'),export_selected_objects=True,export_materials=True,apply_modifiers=True)
    report['obj_export']='exports/Zenith2100.obj'
(ROOT/'logs'/'final_file_validation.json').write_text(json.dumps(report,indent=2))
print('ZENITH_FILE_AUDIT',json.dumps(report),flush=True)
if errors:raise RuntimeError('; '.join(errors))
