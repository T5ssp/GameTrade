"""Draw two vector concept plans from the documented Zenith scene coordinates.

Standard library only; does not run Blender or read files outside this project.
The diagram is a schematic presentation aid, not an architectural CAD issue.
Run from the project folder: python3 scripts/draw_concept_plans.py
"""
from html import escape
from math import cos, sin, pi
from pathlib import Path
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
OUTPUT = ROOT / 'docs' / 'CONCEPT_PLANS.svg'
SCALE = 10.5  # pixels per metre, common to both plans
WIDTH, HEIGHT = 1400, 900
NAVY, GOLD, CYAN, ORANGE = '#102d42', '#b58c4d', '#388e9e', '#b96336'
PAPER, STONE, GREY = '#f3f0e8', '#e9e3d7', '#7a8b92'
GROUND_TABLES = [(x, y) for x in (-16.0, -10.5, 10.5, 16.0)
                 for row, y in enumerate((-6.0, -.7, 4.4))
                 if not (x == -16.0 and row == 1)]
UPPER_TABLES = [(-14, -5), (-15, 1), (-14, 6), (10, -7), (15, -3)]
PRIVATE_PODS = [(10, 7.5), (16, 2.5)]
KITCHEN = [(-17.8, 7.8), (-17.6, 8.25), (-15, 10.05), (-10, 12.1),
           (-4, 12.7), (-3, 12.55), (-3, 7.8)]
STAIR_LANDING = [(-20.75, 3.15), (-18.15, 3.15), (-18.15, 4.5),
                 (-20.2, 4.5), (-20.45, 3.95)]


class Diagram:
    def __init__(self):
        self.parts = []
        self.panel_x = 0
        self.origin = (0, 0)

    def add(self, markup):
        self.parts.append(markup)

    def xy(self, x, y):
        return self.origin[0] + x*SCALE, self.origin[1] - y*SCALE

    def path(self, points, close=False):
        coords = [self.xy(x, y) for x, y in points]
        return 'M ' + ' L '.join(f'{x:.2f},{y:.2f}' for x, y in coords) + (' Z' if close else '')

    def polygon(self, points, fill='none', stroke=NAVY, width=1, extra=''):
        self.add(f'<path d="{self.path(points,True)}" fill="{fill}" stroke="{stroke}" stroke-width="{width}" {extra}/>')

    def polyline(self, points, stroke=NAVY, width=1, extra=''):
        self.add(f'<path d="{self.path(points)}" fill="none" stroke="{stroke}" stroke-width="{width}" stroke-linejoin="round" stroke-linecap="round" {extra}/>')

    def rect(self, x0, y0, x1, y1, fill='none', stroke=NAVY, width=1, radius=0):
        sx, sy = self.xy(x0, y1)
        self.add(f'<rect x="{sx:.2f}" y="{sy:.2f}" width="{(x1-x0)*SCALE:.2f}" height="{(y1-y0)*SCALE:.2f}" rx="{radius}" fill="{fill}" stroke="{stroke}" stroke-width="{width}"/>')

    def ellipse(self, x, y, rx, ry, fill='none', stroke=NAVY, width=1, extra=''):
        sx, sy = self.xy(x, y)
        self.add(f'<ellipse cx="{sx:.2f}" cy="{sy:.2f}" rx="{rx*SCALE:.2f}" ry="{ry*SCALE:.2f}" fill="{fill}" stroke="{stroke}" stroke-width="{width}" {extra}/>')

    def label(self, x, y, text, size=10, fill=NAVY, anchor='middle', weight='400', extra=''):
        sx, sy = self.xy(x, y)
        self.screen_text(sx, sy, text, size, fill, anchor, weight, extra)

    def screen_text(self, x, y, text, size=10, fill=NAVY, anchor='start', weight='400', extra=''):
        self.add(f'<text x="{x:.2f}" y="{y:.2f}" font-size="{size}" fill="{fill}" text-anchor="{anchor}" font-weight="{weight}" {extra}>{escape(text)}</text>')

    def dining_table(self, x, y, private=False, outdoor=False):
        color = '#dccba9' if private else '#fefcf7'
        self.ellipse(x, y, .79, .79, color, GOLD, 1.05)
        self.ellipse(x, y, .22, .22, '#c3cfb9', '#7a956f', .6)
        for index in range(4):
            angle = index*pi/2
            cx, cy = x+1.22*cos(angle), y+1.22*sin(angle)
            self.ellipse(cx, cy, .29, .29, '#c1cbd0' if outdoor else '#b6c3c9', '#577284', .65)
        # A small dark tablet indicates the interactive-table program.
        self.rect(x-.19, y-.63, x+.19, y-.40, NAVY, NAVY, .5, 1)

    def circulation(self, points, guest=True, opacity=1):
        color = CYAN if guest else ORANGE
        dashed = '' if guest else 'stroke-dasharray="5 4"'
        self.polyline(points, color, 2.4, f'marker-end="url(#{"guest" if guest else "service"}Arrow)" opacity="{opacity}" {dashed}')

    def stairs(self, upper=False):
        self.rect(-20.8, -4.35, -18.4, 3.21, '#e0dbd1', NAVY, 1.0)
        for index in range(28):
            y = -4.35 + .28*index
            self.polyline([(-20.8, y), (-18.4, y)], GREY, .55)
        self.polygon(STAIR_LANDING, '#e0dbd1', NAVY, .9)
        arrow = [(-19.6, 2.65), (-19.6, -3.8)] if upper else [(-19.6, -3.8), (-19.6, 2.65)]
        self.polyline(arrow, NAVY, 1.35, 'marker-end="url(#navyArrow)"')
        self.label(-22.05, -.2, 'DN' if upper else 'UP', 9, NAVY)

    def lift(self):
        self.rect(1.55, 7.5, 4.45, 10.4, '#edf4f4', NAVY, 1.2)
        self.rect(1.80, 7.78, 4.2, 10.10, 'none', '#96aeb8', .6)
        self.polyline([(1.55, 7.5), (4.45, 10.4)], '#96aeb8', .6)
        self.polyline([(4.45, 7.5), (1.55, 10.4)], '#96aeb8', .6)
        self.label(3.0, 8.70, 'LIFT', 8.5, NAVY, weight='600')

    def dimensions(self):
        self.polyline([(-22, 15.4), (22, 15.4)], GREY, .7)
        for x in (-22, 22):
            self.polyline([(x, 14.8), (x, 16.0)], GREY, .7)
        self.label(0, 16.15, '44.0 m approximate facade span', 9, GREY)

    def panel(self, x, title, subtitle, level):
        self.panel_x = x
        self.origin = (x+320, 444)
        self.add(f'<rect x="{x}" y="156" width="640" height="572" rx="18" fill="#fffdf8" stroke="#d3d9d8"/>')
        self.screen_text(x+24, 188, title, 20, NAVY, weight='600')
        self.screen_text(x+24, 211, subtitle, 10.5, GREY)
        self.screen_text(x+616, 190, level, 12, GOLD, 'end', '600')
        self.dimensions()
        # North arrow agrees with scene +Y, independent of presentation cameras.
        self.add(f'<path d="M {x+597},270 L {x+597},237 M {x+597},237 l -5,11 l 5,-4 l 5,4 Z" stroke="{NAVY}" fill="{NAVY}" stroke-width="1"/>')
        self.screen_text(x+597, 229, 'N / +Y', 9, NAVY, 'middle', '600')


def perimeter(a, b, count=160, cy=0):
    return [(a*cos(2*pi*i/count), cy+b*sin(2*pi*i/count)) for i in range(count)]


def ground_plan(d):
    d.panel(40, '01  Ground floor', '11 dining tables / 44 seats + reception and service', 'FFL +0.55 m')
    d.polygon(perimeter(22.7,14.4), STONE, '#acb4b5', 1)
    d.polygon(perimeter(22.0,13.8), '#f9f6ef', NAVY, 2.0)
    # Different room fills clarify the functional zoning without claiming fire compartments.
    d.polygon(KITCHEN, '#e0e7e9', NAVY, 1.2)
    d.rect(-13.2, 8.90, -7.4, 10.0, '#a8b7bf', '#526d7d', .8)
    d.rect(-7.6, 11.35, -4.0, 12.10, '#b9c5ca', '#526d7d', .7)
    d.rect(-16.15, 8.2, -14.95, 9.10, '#b9c5ca', '#526d7d', .7)
    d.label(-10.4, 10.8, 'KITCHEN / PREP', 10, NAVY, weight='600')
    d.label(-10.4, 8.25, 'STAFF ZONE', 7.5, '#667d8b')
    d.rect(-2.6, 6.48, 2.2, 7.26, '#cdb38b', GOLD, .8)
    d.label(-.2, 6.75, 'PICKUP', 7, NAVY, weight='600')
    for name, x0, x1, y0, y1 in [('ACCESSIBLE',7,10.4,8,11.4),('WC',11,14,7.85,9.95),('STAFF WC',4.8,6.65,11,12.75)]:
        d.rect(x0,y0,x1,y1,'#e7dfd1',NAVY,.9)
        d.label((x0+x1)/2,(y0+y1)/2+.12,name,6.6 if name!='WC' else 8,NAVY,weight='600')
    # The accessible turning inlay matches the actual sanitary fixture model.
    d.ellipse(8.65,9.2,.75,.75,'none',GOLD,.65,extra='stroke-dasharray="2 2"')
    d.lift()
    d.stairs()
    d.ellipse(0,-1,7.2,5.5,'#edf1e7','#c0b58e',1,extra='stroke-dasharray="4 3"')
    d.ellipse(0,-1,2.45,2.45,'#a8c8cb',GOLD,1.1)
    d.polyline([(-1.1,-2.3),(.9,-1.5),(-.7,-.4),(1.0,.4)],GOLD,2.6)
    d.label(0,2.1,'DAYLIT ATRIUM',10,NAVY,weight='600')
    d.label(0,1.0,'Double-height volume above',7.8,GREY)
    for x,y in GROUND_TABLES:
        d.dining_table(x,y)
    # Concierge crescent follows the actual open-arc desk footprint.
    outer=[(5+2.1*cos((190+i*160/30)*pi/180),-10.1+2.1*sin((190+i*160/30)*pi/180)) for i in range(31)]
    inner=[(5+1.68*cos((190+i*160/30)*pi/180),-10.1+1.68*sin((190+i*160/30)*pi/180)) for i in range(30,-1,-1)]
    d.polygon(outer+inner,'#c4ab83',GOLD,.8)
    d.label(7.1,-12.7,'CONCIERGE',8,NAVY,weight='600')
    d.rect(-6.7,-11.43,-3.7,-10.57,'#c0c9cb','#6b8592',.8,2)
    d.rect(-7.58,-11.2,-6.72,-8.2,'#c0c9cb','#6b8592',.8,2)
    d.ellipse(-4.95,-9.5,.62,.62,'#e4d8c5',GOLD,.7)
    d.label(-7.3,-12.7,'WAITING',8,NAVY,weight='600')
    # Six external tables match the side terraces; their footprint is not inside the facade.
    for side in (-1,1):
        d.rect(side*25-3.05,-6.9,side*25+3.05,7.9,'#e4d7bf','#c0ad88',.8,5)
        for y in (-4,.5,5):
            d.dining_table(side*25,y,outdoor=True)
        d.label(side*25,-8.35,'12 OUTDOOR',7.4,GREY,weight='600')
    # Public approach enters through the ground glazing gap.
    d.polyline([(-3.3,-13.8),(3.3,-13.8)],'#fffdf8',4.5)
    d.polyline([(-3.3,-13.8),(-3.3,-14.5)],GOLD,1.4)
    d.polyline([(3.3,-13.8),(3.3,-14.5)],GOLD,1.4)
    for i,y in enumerate((-14.8,-15.5,-16.2)):
        d.rect(-4,y-.35,4,y+.35,'#e5ded0','#bcb9ae',.65)
    d.rect(-4,-20.3,4,-16.6,'#ece5d7','#c4bda9',.65)
    d.label(0,-22.1,'SOUTH ARRIVAL / MAIN ENTRANCE',9,NAVY,weight='600')
    d.circulation([(0,-20),(0,-14),(0,-8.0)])
    d.circulation([(0,-8),(-5.8,-7.4),(-8.1,-4.0),(-8.2,1.0),(-5.8,5.3)],True,.9)
    d.circulation([(0,-8),(5.8,-7.4),(8.1,-4.0),(8.2,1.0),(5.8,5.3)],True,.9)
    d.circulation([(-10.8,10.7),(-5.22,10.7),(-5.22,6.9),(-2.8,6.9)],False)
    d.circulation([(2.6,6.1),(6.8,4.8),(8.0,1.0),(8.0,-5.8),(6.2,-7.9)],False,.70)
    d.screen_text(64,704,'Guest approach remains separate from kitchen work aisles.',10,GREY)


def upper_plan(d):
    d.panel(720, '02  Upper dining level', '5 open dining tables / 20 seats + 2 private suites / 8 seats', 'FFL +5.25 m')
    outside=perimeter(21.65,13.3)
    inside=perimeter(7.2,5.5,cy=-1)
    opening=[(-21.9,-4.95),(-18.1,-4.95),(-18.1,4.15),(-21.9,4.15)]
    compound=d.path(outside,True)+' '+d.path(list(reversed(inside)),True)+' '+d.path(opening,True)
    d.add(f'<defs><clipPath id="upperFloorClip"><path d="{d.path(outside,True)}"/></clipPath></defs>')
    d.add(f'<path d="{compound}" fill="#f5f0e5" stroke="{NAVY}" stroke-width="1.5" fill-rule="evenodd" clip-path="url(#upperFloorClip)"/>')
    d.polygon(inside,'url(#voidHatch)','#b7c7cc',.8)
    d.ellipse(0,-1,7.23,5.53,'none',GOLD,1.4)
    d.label(0,.6,'OPEN TO BELOW',11,NAVY,weight='600')
    d.label(0,-.7,'Atrium void / overlook',8.5,GREY)
    d.stairs(upper=True)
    d.lift()
    for x,y in UPPER_TABLES:
        d.dining_table(x,y)
    for index,(x,y) in enumerate(PRIVATE_PODS):
        d.ellipse(x,y,2.35,2.35,'#dce9e8','none',0)
        wall=[(x+2.35*cos((-50+i*280/70)*pi/180),y+2.35*sin((-50+i*280/70)*pi/180)) for i in range(71)]
        d.polyline(wall,GOLD,1.8)
        d.dining_table(x,y,private=True)
        d.label(x,y+3.15,f'PRIVATE SUITE {index+1:02}',8,NAVY,weight='600')
    d.rect(1.67,7.62,4.33,10.32,'url(#liftHatch)',NAVY,.8)
    d.label(3,8.7,'LIFT',8.5,NAVY,weight='600')
    # Hanging gardens are shown at the actual four edge-planter centres.
    for x,y in [(-18,-6),(18,-6),(-18,6),(18,6)]:
        d.ellipse(x,y,.58,.58,'#bccbb0','#728c66',.8)
        d.polyline([(x-.42,y-.1),(x,y+.38),(x+.42,y-.08)],'#6d8a5d',.9)
    d.circulation([(3,7.1),(3,6.1),(-1,5.7),(-6.2,3.6),(-8.2,0),(-7.3,-4.7),(-2.0,-7.0)],True,.85)
    d.circulation([(3,6.1),(6.4,5.7),(9.8,4.6)],True,.85)
    d.circulation([(6.0,-6.4),(8.4,-3.5),(10.6,-.6),(13.0,.2),(16,-.2)],True,.85)
    d.label(-13,9.1,'OPEN DINING / OVERLOOK',8.5,NAVY,weight='600')
    d.label(0,-16.3,'VOID + STAIR + LIFT OPENINGS ARE MODELED IN 3D',8.7,GREY)
    d.screen_text(744,704,'Transparent pods have south-facing entry gaps and individual tables.',10,GREY)


def build():
    d=Diagram()
    d.add(f'<svg xmlns="http://www.w3.org/2000/svg" width="{WIDTH}" height="{HEIGHT}" viewBox="0 0 {WIDTH} {HEIGHT}" role="img" aria-labelledby="title desc">')
    d.add('<title id="title">The Zenith 2100 – Ground and upper-level concept plans</title>')
    d.add('<desc id="desc">A schematic pair of plans showing actual table positions, main arrival, concierge, waiting lounge, kitchen, pickup counter, sanitary facilities, western stair, lift, central atrium and two upper private dining suites. Actual design seating: seventy-two indoor and twenty-four outdoors.</desc>')
    d.add(f'<defs><marker id="guestArrow" markerWidth="7" markerHeight="7" refX="6" refY="3.5" orient="auto"><path d="M0,0 L7,3.5 L0,7 Z" fill="{CYAN}"/></marker><marker id="serviceArrow" markerWidth="7" markerHeight="7" refX="6" refY="3.5" orient="auto"><path d="M0,0 L7,3.5 L0,7 Z" fill="{ORANGE}"/></marker><marker id="navyArrow" markerWidth="5" markerHeight="5" refX="4.5" refY="2.5" orient="auto"><path d="M0,0 L5,2.5 L0,5 Z" fill="{NAVY}"/></marker><pattern id="voidHatch" width="9" height="9" patternUnits="userSpaceOnUse"><path d="M-2,2 L2,-2 M0,9 L9,0 M7,11 L11,7" stroke="#c5d4d5" stroke-width=".7"/></pattern><pattern id="liftHatch" width="6" height="6" patternUnits="userSpaceOnUse"><path d="M0,6 L6,0" stroke="#d3dde0" stroke-width=".6"/></pattern></defs>')
    d.add(f'<g font-family="Arial, Helvetica, sans-serif"><rect width="{WIDTH}" height="{HEIGHT}" fill="{PAPER}"/>')
    d.add(f'<rect x="0" y="0" width="{WIDTH}" height="123" fill="{NAVY}"/>')
    d.screen_text(42,48,'THE ZENITH 2100',30,'#f5f0e6',weight='600')
    d.screen_text(43,78,'FUTURISTIC LUXURY RESTAURANT',12,'#c9dce2',extra='letter-spacing="3"')
    d.screen_text(1358,48,'SPATIAL ORGANIZATION',16,'#dbc398','end','600')
    d.screen_text(1358,77,'CONCEPT PLANS  /  METRES  /  NORTH UP',11,'#c9dce2','end')
    ground_plan(d)
    upper_plan(d)
    d.add('<path d="M40 756 H1360" stroke="#c4ccc9" stroke-width="1"/>')
    # A common scale bar is legible and deliberately not a print-scale claim.
    bx,by=46,791
    d.add(f'<rect x="{bx}" y="{by}" width="{5*SCALE}" height="8" fill="{NAVY}"/><rect x="{bx+5*SCALE}" y="{by}" width="{5*SCALE}" height="8" fill="#fffdf8" stroke="{NAVY}" stroke-width=".8"/>')
    for x,label in [(bx,'0'),(bx+5*SCALE,'5 m'),(bx+10*SCALE,'10 m')]:
        d.screen_text(x,817,label,10,GREY,'middle')
    d.screen_text(46,843,'Common diagram scale; resize freely as a vector.',9,GREY)
    d.add(f'<path d="M267 791 H310" stroke="{CYAN}" stroke-width="2.4" marker-end="url(#guestArrow)"/>')
    d.screen_text(322,795,'GUEST CIRCULATION',10,NAVY,weight='600')
    d.add(f'<path d="M267 821 H310" stroke="{ORANGE}" stroke-width="2.4" stroke-dasharray="5 4" marker-end="url(#serviceArrow)"/>')
    d.screen_text(322,825,'STAFF / ROBOT SERVICE',10,NAVY,weight='600')
    d.screen_text(608,791,'DESIGN CAPACITY',10,GREY,weight='600')
    d.screen_text(608,818,'72 indoor + 24 outdoor = 96 seats',15,NAVY,weight='600')
    d.screen_text(608,842,'11 ground + 5 upper + 2 private tables; all four-seat.',9,GREY)
    d.screen_text(1010,790,'SCHEMATIC, NOT A CONSTRUCTION DRAWING',10,NAVY,weight='600')
    d.screen_text(1010,812,'Based on the editable Blender scene coordinates.',10,GREY)
    d.screen_text(1010,832,'Areas are preliminary program allowances, not CAD take-offs.',9,GREY)
    d.screen_text(1010,851,'Access, egress and building services require detailed design.',9,GREY)
    d.add('</g></svg>')
    OUTPUT.parent.mkdir(exist_ok=True)
    OUTPUT.write_text('\n'.join(d.parts),encoding='utf-8')
    ET.parse(OUTPUT)
    assert len(GROUND_TABLES)==11 and len(UPPER_TABLES)==5 and len(PRIVATE_PODS)==2
    assert all(abs(x)<22 and abs(y)<14 for x,y in GROUND_TABLES+UPPER_TABLES+PRIVATE_PODS)
    return OUTPUT


if __name__=='__main__':
    target=build()
    print(f'Created and XML-validated {target}')
    print('Tables: ground11 / upper5 / private2 / outdoor6; indoor72 + outdoor24 =96 seats')
