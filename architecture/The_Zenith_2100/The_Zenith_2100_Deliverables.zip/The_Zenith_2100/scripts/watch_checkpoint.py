"""Refresh the project checkpoint after each completed render/source change."""
from pathlib import Path
import time,os,json
from save_checkpoint import ROOT,save_checkpoint
(ROOT/'logs/checkpoint_watch.pid').write_text(str(os.getpid()))
last=None
while True:
    paths=[ROOT/'Zenith2100.blend',ROOT/'README.md',ROOT/'logs/presentation_presentation.json']
    paths+=sorted((ROOT/'scripts').glob('*.py'))+sorted((ROOT/'docs').glob('*'))+sorted((ROOT/'cameras').glob('*.json'))
    signature=tuple((str(p.relative_to(ROOT)),p.stat().st_mtime_ns,p.stat().st_size) for p in paths if p.is_file())
    if signature!=last:
        try:
            state=save_checkpoint();last=signature
            print(state['updated_dubai'],'CHECKPOINT',len(state['completed_cameras']),'of9',flush=True)
            if not state['remaining_cameras']:break
        except (OSError,ValueError,AssertionError) as error:
            print('Checkpoint waiting for a consistent completed file:',str(error),flush=True)
    time.sleep(15)
