import bpy,json
from pathlib import Path
bpy.context.scene.use_nodes=True;nodes=bpy.context.scene.node_tree.nodes
report={}
for name in ['CompositorNodeBilateralblur','CompositorNodeKuwahara','CompositorNodeBlur']:
 try:
  node=nodes.new(name);report[name]={'inputs':[i.name for i in node.inputs],'properties':{p.identifier:str(getattr(node,p.identifier)) for p in node.bl_rna.properties if p.identifier in ['iterations','sigma_color','sigma_space','variation','size','filter_type','size_x','size_y']}}
 except Exception as error:report[name]={'error':str(error)}
Path('/workspace/The_Zenith_2100/logs/compositor_capabilities.json').write_text(json.dumps(report,indent=2))
print(json.dumps(report))
