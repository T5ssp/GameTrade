"""Editable arrival, terrace and planting geometry for The Zenith 2100.

All dimensions are metres. No operators read external files. The main builder
provides PBR materials and shared geometry helpers from ``zenith_lib``.
"""
from math import cos, sin, pi, sqrt
from random import Random

import bpy
from zenith_lib import cube, cylinder, sphere, curve, mesh

SITE = '90_Site_Arrival'
LAND = '91_Landscape_Gardens'
TERRACE = '92_Outdoor_Terraces'


def _strip(name, centre_points, width, z, mat, collection=SITE):
    """A ribbon mesh following a polyline; width is measured in the XY plane."""
    vertices = []
    for index, point in enumerate(centre_points):
        previous = centre_points[max(0, index - 1)]
        following = centre_points[min(len(centre_points) - 1, index + 1)]
        dx, dy = following[0] - previous[0], following[1] - previous[1]
        length = sqrt(dx * dx + dy * dy) or 1.0
        nx, ny = -dy / length, dx / length
        vertices.extend([(point[0] + nx * width / 2, point[1] + ny * width / 2, z),
                         (point[0] - nx * width / 2, point[1] - ny * width / 2, z)])
    faces = [(2*i, 2*i+1, 2*i+3, 2*i+2) for i in range(len(centre_points)-1)]
    return mesh(name, vertices, faces, mat, collection=collection)


def _organic_ring(name, cx, cy, rx, ry, outer, z_top, z_bottom, mat):
    vertices, faces = [], []
    segments = 72
    for z in (z_top, z_bottom):
        for offset in (outer, 0):
            for i in range(segments):
                angle = 2*pi*i/segments
                # A quiet kidney-shaped curve, rather than a generic circle.
                x = (rx+offset)*cos(angle) * (1 + .025*sin(3*angle))
                y = (ry+offset)*sin(angle) + .23*cos(2*angle)
                vertices.append((cx+x, cy+y, z))
    for i in range(segments):
        nxt = (i+1) % segments
        faces.extend([(i,nxt,segments+nxt,segments+i),
                      (i,2*segments+i,2*segments+nxt,nxt),
                      (segments+i,segments+nxt,3*segments+nxt,3*segments+i),
                      (2*segments+i,3*segments+i,3*segments+nxt,2*segments+nxt)])
    return mesh(name, vertices, faces, mat, collection=SITE)


def _pool(name, cx, cy, rx, ry, materials):
    _organic_ring(name+'_Stone_Coping',cx,cy,rx,ry,.24,.13,-.08,materials['stone'])
    vertices=[(cx,cy,.065)]
    for i in range(72):
        angle=2*pi*i/72
        vertices.append((cx+rx*cos(angle)*(1+.025*sin(3*angle)),
                         cy+ry*sin(angle)+.23*cos(2*angle),.065))
    faces=[(0,i+1,(i+1)%72+1) for i in range(72)]
    mesh(name+'_Reflecting_Water',vertices,faces,materials['water'],collection=SITE)
    # The gold accent sits in the coping, above water and outside the walkway.
    accent=[]
    for i in range(73):
        a=2*pi*i/72
        accent.append((cx+(rx+.10)*cos(a)*(1+.025*sin(3*a)),
                       cy+(ry+.10)*sin(a)+.23*cos(2*a),.145))
    curve(name+'_Bronze_Reveal',accent,.016,materials['gold'],collection=SITE)


def _leaf_rosette(name, location, scale, materials, seed=0, collection=LAND):
    """One mesh contains individual curved leaf strips, retaining low object count."""
    random=Random(seed)
    vertices,faces=[],[]
    x,y,z=location
    for leaf in range(15):
        a=leaf*2*pi/15+random.uniform(-.10,.10)
        length=random.uniform(.65,1.25)*scale
        rise=random.uniform(.75,1.50)*scale
        start=len(vertices)
        for step in range(8):
            t=step/7
            radius=.04*scale+length*t*t
            width=.10*scale*sin(pi*t)**.7
            zz=z+rise*sin(pi*.63*t)
            cx=x+cos(a)*radius
            cy=y+sin(a)*radius
            vertices.extend([(cx-sin(a)*width,cy+cos(a)*width,zz),
                             (cx+sin(a)*width,cy-cos(a)*width,zz)])
        for step in range(7):
            j=start+step*2
            faces.append((j,j+1,j+3,j+2))
    obj=mesh(name,vertices,faces,materials['leaf'],collection=collection)
    solid=obj.modifiers.new('Leaf thickness','SOLIDIFY')
    solid.thickness=.008*scale
    return obj


def _planter(name, location, radius, materials, seed):
    x,y,z=location
    cylinder(name+'_Planter', (x,y,z+.24),radius,.48,materials['ivory'],collection=LAND,vertices=32)
    cylinder(name+'_Rim', (x,y,z+.47),radius+.025,.045,materials['gold'],collection=LAND,vertices=32)
    _leaf_rosette(name+'_Arching_Leaves',(x,y,z+.48),radius*.75,materials,seed)


def _tree(name, location, height, materials, seed):
    random=Random(seed)
    x,y,z=location
    cylinder(name+'_Tree_Well',(x,y,z+.06),1.15,.12,materials['stone'],collection=LAND,vertices=32)
    trunk_points=[(x,y,z+.10),(x+.12,y,z+height*.35),(x-.10,y+.13,z+height*.70)]
    curve(name+'_Trunk',trunk_points,.15,materials['wood'],collection=LAND)
    clusters=[]
    for branch in range(4):
        a=branch*pi/2+.35
        point=(x+1.15*cos(a),y+1.15*sin(a),z+height*.83+(.24 if branch%2 else -.1))
        curve(name+f'_Branch_{branch+1}',[trunk_points[1],trunk_points[2],point],.065,materials['wood'],collection=LAND)
        clusters.append(point)
    # Botanical leaves as one instanced-looking mesh, not a cluster of balls.
    vertices,faces=[],[]
    for cluster in clusters:
        for leaf in range(85):
            a=leaf*2.3999632297
            zz=random.uniform(-.8,.8)
            r=sqrt(max(0,1-zz*zz))*random.uniform(.35,1.2)
            xx=cluster[0]+r*cos(a)
            yy=cluster[1]+r*sin(a)
            zc=cluster[2]+zz*.78
            orientation=random.uniform(0,2*pi)
            length=random.uniform(.13,.26)
            width=length*.30
            ux,uy=cos(orientation),sin(orientation)
            vx,vy=-uy,ux
            start=len(vertices)
            vertices.extend([(xx-ux*length,yy-uy*length,zc-.015),
                             (xx+vx*width,yy+vy*width,zc+.035),
                             (xx+ux*length,yy+uy*length,zc+.06),
                             (xx-vx*width,yy-vy*width,zc+.035)])
            faces.append((start,start+1,start+2,start+3))
    obj=mesh(name+'_Individual_Leaf_Canopy',vertices,faces,materials['leaf'],collection=LAND)
    obj['leaf_count']=len(faces)
    obj['botanical_role']='Evergreen shade canopy; conceptual species'


def _chair(name,cx,cy,floor_z,angle,materials):
    """A separate low-poly chair mesh with an editable shell and bronze support."""
    vertices,faces=[],[]
    material_indices=[]
    def box(x0,x1,y0,y1,z0,z1,material=0):
        k=len(vertices)
        points=[(x0,y0,z0),(x1,y0,z0),(x1,y1,z0),(x0,y1,z0),
                (x0,y0,z1),(x1,y0,z1),(x1,y1,z1),(x0,y1,z1)]
        for x,y,z in points:
            vertices.append((cx+x*cos(angle)-y*sin(angle),cy+x*sin(angle)+y*cos(angle),floor_z+z))
        faces.extend([(k,k+3,k+2,k+1),(k+4,k+5,k+6,k+7),(k,k+1,k+5,k+4),
                      (k+1,k+2,k+6,k+5),(k+2,k+3,k+7,k+6),(k+3,k,k+4,k+7)])
        material_indices.extend([material]*6)
    box(-.29,.29,-.27,.27,.42,.50)
    box(-.29,.29,.20,.29,.48,.95)
    box(-.20,-.15,-.18,.18,.04,.43,1)
    box(.15,.20,-.18,.18,.04,.43,1)
    obj=mesh(name,vertices,faces,materials['fabric'],collection=TERRACE)
    obj.data.materials.append(materials['gold'])
    for polygon,index in zip(obj.data.polygons,material_indices):
        polygon.material_index=index
    bevel=obj.modifiers.new('Soft chair edges','BEVEL')
    bevel.width=.035
    bevel.segments=2
    obj['furniture_type']='Outdoor dining chair'
    return obj


def _outdoor_table(name,x,y,materials):
    z=.35
    cylinder(name+'_Base',(x,y,z+.03),.39,.06,materials['gold'],collection=TERRACE,vertices=32)
    cylinder(name+'_Pedestal',(x,y,z+.37),.11,.67,materials['titanium'],collection=TERRACE,vertices=24)
    cylinder(name+'_Stone_Top',(x,y,z+.75),.76,.065,materials['stone'],collection=TERRACE,vertices=48)
    cylinder(name+'_Edge_Reveal',(x,y,z+.72),.755,.018,materials['gold'],collection=TERRACE,vertices=48)
    tablet=cube(name+'_Smart_Tablet',(x+.25,y,z+.81),(.24,.16,.018),materials['dark_glass'],collection=TERRACE,bevel=.012)
    tablet.rotation_euler.x=.12
    for index in range(4):
        a=index*pi/2
        # Local +Y is the chair back, so the seat faces the table.
        _chair(name+f'_Chair_{index+1}',x+1.27*cos(a),y+1.27*sin(a),z,a-pi/2,materials)


def _ramp(materials):
    x0,x1=5.0,14.0
    y0,y1=-15.65,-13.85
    # High end x=5, low end x=14: exactly 0.45m over a 9m horizontal run.
    verts=[(x0,y0,.10),(x1,y0,.10),(x1,y1,.10),(x0,y1,.10),
           (x0,y0,.55),(x0,y1,.55)]
    faces=[(0,3,2,1),(4,1,2,5),(0,1,4),(3,5,2),(0,4,5,3)]
    obj=mesh('Arrival_Accessible_Ramp_1_to_20',verts,faces,materials['floor'],collection=SITE)
    obj['clear_width_m']=1.8
    obj['slope']='1:20 conceptual; verify local access regulations'
    for side,y in enumerate((y0+.06,y1-.06)):
        curve(f'Ramp_Handrail_{side+1}',[(x0,y,1.45),(x1,y,1.0)],.027,materials['gold'],collection=SITE)
        for index in range(4):
            x=x0+(x1-x0)*index/3
            zz=.55-.45*(x-x0)/(x1-x0)
            cylinder(f'Ramp_Post_{side+1}_{index+1}',(x,y,zz+.45),.026,.90,materials['titanium'],collection=SITE,vertices=12)
    cube('Ramp_Upper_Landing',(5,-13.25,.49),(2.4,2.4,.12),materials['floor'],collection=SITE,bevel=.03)
    _strip('East_Accessible_Approach',[(26,-7),(24,-10.5),(20,-13),(14,-14.7)],1.85,.10,materials['floor'])


def build_landscape(materials):
    """Build scene stage4 landscape. Keep every assembly separately selectable."""
    cube('Site_Foundation',(0,0,-.19),(74,62,.28),materials['floor'],collection=SITE,bevel=.4)
    # The road is distinct from pedestrian paving and has no decorative crossings.
    road=[(-35+i*70/56,-28+1.4*((-35+i*70/56)/35)**2) for i in range(57)]
    _strip('Arrival_Dropoff_Road',road,5.0,-.025,materials['black'])
    for offset in (-2.55,2.55):
        points=[(x,y+offset,.015) for x,y in road]
        curve('Road_Edge_'+str(offset),points,.035,materials['titanium'],collection=SITE)
    for index in range(12):
        x=-32+index*5.8
        y=-28+1.4*(x/35)**2
        cube(f'Dropoff_Lane_Marker_{index+1}',(x,y,.002),(2.4,.075,.01),materials['gold'],collection=SITE,bevel=.01)
    cube('Arrival_Pedestrian_Bridge',(0,-21.0,.04),(8.0,10.8,.12),materials['stone'],collection=SITE,bevel=.08)
    for index,(y,height,depth) in enumerate([(-16.20,.25,.70),(-15.50,.40,.70),(-14.80,.55,.70)]):
        cube(f'Main_Entrance_Step_{index+1}',(0,y,height/2),(8.0,depth,height),materials['floor'],collection=SITE,bevel=.025)
        cube(f'Main_Step_Bronze_Nosing_{index+1}',(0,y-.32,height+.006),(7.9,.035,.014),materials['gold'],collection=SITE,bevel=.005)
    _ramp(materials)
    _pool('West_Reflecting_Pool',-15.0,-19.5,8.6,3.0,materials)
    _pool('East_Reflecting_Pool',15.7,-19.5,8.1,3.0,materials)
    # Arrival illumination is warm at pedestrian level, with a restrained cool reveal.
    for side in (-1,1):
        for index,y in enumerate((-23.2,-19.8,-16.8)):
            x=side*4.45
            cylinder(f'Arrival_Bollard_{side}_{index}',(x,y,.37),.10,.70,materials['titanium'],collection=SITE,vertices=20)
            cylinder(f'Arrival_Bollard_Light_{side}_{index}',(x,y,.67),.108,.075,materials['light_warm'],collection=SITE,vertices=20)
        for index,y in enumerate((-4.0,.5,5.0)):
            _outdoor_table(f'Outdoor_{"West" if side<0 else "East"}_Table_{index+1}',side*25.0,y,materials)
        cube(f'{"West" if side<0 else "East"}_Dining_Terrace',(side*25,.5,.18),(6.1,14.8,.34),materials['wood'],collection=TERRACE,bevel=.15)
        # Slender open pergola makes this an outdoor room without competing with the shell.
        for index,y in enumerate((-6.4,7.4)):
            cube(f'Pergola_Post_{side}_{index}',(side*27.5,y,1.95),(.10,.10,3.2),materials['titanium'],collection=TERRACE,bevel=.025)
        curve(f'Pergola_Outer_Ribbon_{side}',[(side*27.5,-6.4,3.55),(side*27.8,.5,3.85),(side*27.5,7.4,3.55)],.055,materials['gold'],collection=TERRACE)
        curve(f'Pergola_Inner_Ribbon_{side}',[(side*23,-6.4,3.50),(side*23,.5,3.75),(side*23,7.4,3.50)],.035,materials['titanium'],collection=TERRACE)
    trees=[(-31,-10.5,5.6),(31,-10.5,5.6),(-31,9,6.0),(31,9,6.0),(-14,24,5.4),(15,24,5.4)]
    for index,(x,y,h) in enumerate(trees):
        _tree(f'Garden_Tree_{index+1}',(x,y,-.035),h,materials,420+index)
    planted=[(-27.5,-8.3,.0,.65),(27.5,-8.3,.0,.65),(-28.0,9,.0,.65),(28.0,9,.0,.65),
             (-8,-14.5,.0,.62),(8,-13.0,.55,.55),(-5,-23,.10,.52),(5,-23,.10,.52),
             (-18,-6,5.25,.50),(18,-6,5.25,.50),(-18,6,5.25,.50),(18,6,5.25,.50)]
    for index,(x,y,z,radius) in enumerate(planted):
        _planter(f'Living_Planter_{index+1}',(x,y,z),radius,materials,170+index)
    # Back-of-site planted courtyards leave the service/loading access clear at centre.
    for side in (-1,1):
        cube(f'Rear_Garden_Bed_{side}',(side*21,19,.12),(9.0,3.8,.30),materials['stone'],collection=LAND,bevel=.65)
        for index in range(4):
            _leaf_rosette(f'Rear_Garden_Shrub_{side}_{index}',(side*21-3+index*2,19,.30),.65,materials,300+index)
    return {'outdoor_tables':6,'outdoor_seats':24,'mature_trees':6,
            'water_basins':2,'accessible_ramp_slope':'1:20','arrival_clear_walk_m':8.0}
