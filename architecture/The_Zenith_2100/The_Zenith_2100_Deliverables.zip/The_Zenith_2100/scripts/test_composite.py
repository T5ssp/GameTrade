"""Test Blender's built-in edge-aware compositor without installing any add-on."""
import bpy
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
bpy.ops.wm.read_factory_settings(use_empty=True)
s=bpy.context.scene;s.render.engine='CYCLES';s.cycles.samples=1;s.cycles.use_denoising=False
bpy.ops.object.camera_add();s.camera=bpy.context.object
image=bpy.data.images.load(str(ROOT/'renders/drafts/01_Hero_Exterior.png'))
s.render.resolution_x=image.size[0];s.render.resolution_y=image.size[1];s.render.resolution_percentage=100;s.render.threads_mode='FIXED';s.render.threads=1
s.use_nodes=True;nodes=s.node_tree.nodes;nodes.clear();links=s.node_tree.links
source=nodes.new('CompositorNodeImage');source.image=image
blur=nodes.new('CompositorNodeBlur');blur.filter_type='GAUSS';blur.size_x=3;blur.size_y=3;links.new(source.outputs['Image'],blur.inputs['Image'])
edge=nodes.new('CompositorNodeBilateralblur');edge.iterations=3;edge.sigma_space=3;edge.sigma_color=.12;links.new(source.outputs['Image'],edge.inputs['Image']);links.new(blur.outputs['Image'],edge.inputs['Determinator'])
out=nodes.new('CompositorNodeComposite');links.new(edge.outputs[0],out.inputs[0]);s.render.filepath=str(ROOT/'logs/compositor_preview.png')
bpy.ops.render.render(write_still=True)
