import bpy,json
from pathlib import Path
from mathutils import Vector
root=Path(__file__).resolve().parents[1]
checks={}
for name,point in [('Lift_Shaft_Opening',(3,8.95,6.0)),('West_Stair_Opening',(-19.6,-.4,6.0)),('Upper_Landing_Support',(-19.0,3.8,6.0)),('Upper_Private_Dining_Support',(10,7.5,6.0))]:
 hits=[]
 for obj in bpy.context.scene.objects:
  if obj.type=='MESH' and (obj.name.startswith('Upper_Atrium_Ring_') or obj.name=='Stair_Upper_Landing'):
   local=obj.matrix_world.inverted()@Vector(point);hit,loc,n,index=obj.ray_cast(local,Vector((0,0,-1)),distance=1.5)
   if hit:hits.append({'mesh':obj.name,'height':loc.z})
 checks[name]={'point':point,'slab_hits':hits}
checks['lift_open']=not checks['Lift_Shaft_Opening']['slab_hits']
checks['stair_open']=not checks['West_Stair_Opening']['slab_hits']
checks['landing_supported']=bool(checks['Upper_Landing_Support']['slab_hits'])
checks['pod_supported']=bool(checks['Upper_Private_Dining_Support']['slab_hits'])
(root/'logs/circulation_geometry.json').write_text(json.dumps(checks,indent=2))
print(json.dumps(checks))

assert all(checks[key] for key in ['lift_open','stair_open','landing_supported','pod_supported']), 'Actual circulation geometry failed'
