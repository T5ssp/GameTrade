"""Editable interior architecture and furniture for The Zenith 2100.

All dimensions are metres.  Ground FFL = 0.55; mezzanine FFL = 5.25.
The module intentionally keeps furnishings, room partitions and equipment in
separate collections and uses linked chair meshes for an editable light scene.
"""
import bpy
import math
from mathutils import Vector
from zenith_lib import cube, cylinder, sphere, curve, text, mesh, collection

GROUND = 0.55
UPPER = 5.25
CHAIRS = {}
COUNTS = {'ground_tables': 0, 'upper_tables': 0, 'private_tables': 0,
          'indoor_seats': 0, 'serving_robots': 0}


def _prism(verts, faces, center, size):
    """Append a box to a compound mesh, avoiding dozens of hidden objects."""
    x, y, z = center
    a, b, c = [value / 2 for value in size]
    offset = len(verts)
    verts.extend([(x-a,y-b,z-c),(x-a,y-b,z+c),(x-a,y+b,z-c),(x-a,y+b,z+c),
                  (x+a,y-b,z-c),(x+a,y-b,z+c),(x+a,y+b,z-c),(x+a,y+b,z+c)])
    faces.extend([tuple(offset+i for i in face) for face in
                  [(0,4,6,2),(1,3,7,5),(0,1,5,4),(2,6,7,3),(0,2,3,1),(4,5,7,6)]])


def _boxes(name, parts, loc, mat, col):
    verts, faces = [], []
    for center, size in parts:
        _prism(verts, faces, center, size)
    obj = mesh(name, verts, faces, mat, col)
    obj.location = loc
    return obj


def _lathe(name, profile, loc, mat, col, count=24, elliptical=1.0):
    verts, faces = [], []
    for radius, height in profile:
        for i in range(count):
            angle = math.tau * i / count
            verts.append((radius*math.cos(angle), elliptical*radius*math.sin(angle), height))
    for j in range(len(profile)-1):
        for i in range(count):
            k = (i+1) % count
            faces.append((j*count+i,j*count+k,(j+1)*count+k,(j+1)*count+i))
    faces.append(tuple(range(count-1,-1,-1)))
    faces.append(tuple((len(profile)-1)*count+i for i in range(count)))
    obj = mesh(name, verts, faces, mat, col)
    obj.location = loc
    for polygon in obj.data.polygons[:-2]:
        polygon.use_smooth = True
    return obj


def _wall(name, start, end, floor, height, material, col='22_Interior_Partitions', thickness=.13):
    start, end = Vector(start), Vector(end)
    middle = (start+end)/2
    obj = cube(name, (middle.x,middle.y,floor+height/2),
               ((end-start).length,thickness,height), material, col, bevel=.015)
    obj.rotation_euler.z = math.atan2(end.y-start.y,end.x-start.x)
    return obj


def _door(name, center, width, floor, height, M, col='22_Interior_Partitions', glass=True, sliding=False):
    x,y = center
    frame = _boxes(name+'_Frame', [((-width/2,0,height/2),(.06,.12,height)),
        ((width/2,0,height/2),(.06,.12,height)),((0,0,height), (width+.08,.12,.06))],
        (x,y,floor), M['gold'], col)
    frame['clear_opening_m'] = round(width-.06,2)
    # The leaf is held open beside the doorway rather than obstructing a route.
    leaf_center=(x-width*.82,y+.06,floor+height/2) if sliding else (x-width/2,y+width/2,floor+height/2)
    leaf = cube(name+'_Open_Leaf',leaf_center,
                (width-.05,.025,height-.08), M['glass'] if glass else M['wood'], col, bevel=.006)
    leaf.rotation_euler.z = 0 if sliding else math.pi/2
    frame['entry_type']='Pocket sliding glass' if sliding else 'Door shown fully open'
    return frame


def _chair_template(M):
    if CHAIRS:
        return
    col = '31_Ground_Dining'
    verts, faces = [], []
    # A continuous sculpted seat, oval in plan, not a rectangular block.
    rings = [(.235,.215,.43),(.29,.26,.47),(.285,.255,.54),(.23,.21,.56)]
    count = 24
    for rx,ry,z in rings:
        for i in range(count):
            a = math.tau*i/count
            verts.append((rx*math.cos(a),ry*math.sin(a),z))
    for j in range(len(rings)-1):
        for i in range(count):
            k=(i+1)%count
            faces.append((j*count+i,j*count+k,(j+1)*count+k,(j+1)*count+i))
    faces.append(tuple(range(count-1,-1,-1)))
    faces.append(tuple((len(rings)-1)*count+i for i in range(count)))
    # Double-skin U back curves around the sitter. Front remains open.
    arc_count = 16
    start = len(verts)
    for thickness in (0,.04):
        for upper in (0,1):
            for i in range(arc_count+1):
                a=math.radians(12+156*i/arc_count)
                rx=.29+thickness+.035*upper
                ry=.21+thickness+.025*upper
                verts.append((rx*math.cos(a),.105+ry*math.sin(a),.49+.49*upper))
    row=arc_count+1
    for i in range(arc_count):
        a=start+i
        faces += [(a,a+1,a+row+1,a+row),
                  (a+2*row,a+3*row,a+3*row+1,a+2*row+1),
                  (a+row,a+row+1,a+3*row+1,a+3*row)]
    faces.extend([(start,start+row,start+3*row,start+2*row),
                  (start+arc_count,start+2*row-1,start+4*row-1,start+3*row-1)])
    shell = mesh('Chair_Sculpted_Shell_Master',verts,faces,M['fabric'],col)
    for face in shell.data.polygons:
        face.use_smooth=True
    base = _lathe('Chair_Titanium_Pedestal_Master',
        [(.22,.02),(.25,.045),(.22,.075),(.065,.12),(.055,.37),(.17,.42)],
        (0,0,0),M['gold'],col)
    # Store only mesh data; delete template objects so the origin is not occupied.
    CHAIRS['shell'] = shell.data
    CHAIRS['base'] = base.data
    bpy.data.objects.remove(shell,do_unlink=True)
    bpy.data.objects.remove(base,do_unlink=True)


def _chair(name,x,y,floor,angle,M,col):
    _chair_template(M)
    for part in ('shell','base'):
        obj=bpy.data.objects.new(name+'_'+part,CHAIRS[part])
        collection(col).objects.link(obj)
        obj.location=(x,y,floor)
        obj.rotation_euler.z=angle
        obj['component']='linked sculpted dining chair'
    COUNTS['indoor_seats'] += 1


def _place_settings(name,x,y,z,M,col):
    # Four porcelain plates are one compound mesh, but remain separate from furniture.
    verts,faces=[],[]
    settings=[]
    for i in range(4):
        angle=i*math.pi/2
        px=x+.50*math.cos(angle);py=y+.50*math.sin(angle)
        settings.append((px,py,angle))
        start=len(verts); n=20
        for radius,height in [(.16,z),(.165,z+.018),(.13,z+.024)]:
            for j in range(n):
                a=math.tau*j/n
                verts.append((px+radius*math.cos(a),py+radius*math.sin(a),height))
        for j in range(n):
            k=(j+1)%n
            faces.extend([(start+j,start+k,start+n+k,start+n+j),
                          (start+n+j,start+n+k,start+2*n+k,start+2*n+j)])
        faces.append(tuple(start+2*n+j for j in range(n)))
    plates=mesh(name+'_Porcelain_Plates',verts,faces,M['ivory'],col)
    for face in plates.data.polygons:face.use_smooth=True
    # Small cutlery and folded napkins are genuine compound 3D meshes.
    utensils=[];napkins=[]
    for px,py,a in settings:
        # Align each setting radially with the table edge.
        tx,ty=-math.sin(a),math.cos(a)
        for side in (-1,1):
            utensils.append(((px+side*.20*tx-x,py+side*.20*ty-y,z+.016),(.018,.19,.012)))
        napkins.append(((px-x,py-y,z+.04),(.13,.11,.035)))
    _boxes(name+'_Gold_Cutlery',utensils,(x,y,0),M['gold'],col)
    _boxes(name+'_Folded_Napkins',napkins,(x,y,0),M['fabric'],col)
    # Two hand-blown hollow glasses, kept low polygon and individually editable.
    for index,angle in enumerate((math.pi/4,5*math.pi/4)):
        _lathe(name+'_Glass_'+str(index+1),[(.058,0),(.052,.008),(.035,.025),(.031,.15),(.04,.17),(.034,.17),(.025,.035)],
               (x+.48*math.cos(angle),y+.48*math.sin(angle),z+.02),M['glass'],col,count=16)


def _smart_menu(name,x,y,floor,M,col,active=False):
    obj=cube(name+'_Embedded_Tablet',(x,y-.29,floor+.805),(.25,.19,.018),M['black'],col,bevel=.009)
    obj.rotation_euler.x=math.radians(9)
    display=cube(name+'_Touch_Display',(x,y-.29,floor+.816),(.224,.158,.004),M['screen'],col,bevel=.001)
    display.rotation_euler.x=math.radians(9)
    if active:
        holo_col='39_Future_Technology'
        panel=cube(name+'_Holographic_Menu',(x,y-.21,floor+1.07),(.28,.018,.31),M['glass'],holo_col,bevel=.004)
        panel.rotation_euler.x=math.radians(12)
        curve(name+'_Hologram_Border',[(x-.15,y-.23,floor+.92),(x-.15,y-.23,floor+1.23),
               (x+.15,y-.23,floor+1.23),(x+.15,y-.23,floor+.92)],.006,M['light_cool'],holo_col)
        text(name+'_Hologram_Title','ZENITH',(x,y-.245,floor+1.15),.045,M['light_cool'],
             rotation=(math.pi/2,0,0),collection=holo_col)
        for j in range(3):
            cube(name+'_Hologram_Line_'+str(j),(x-.018,y-.25,floor+1.065-j*.042),(.17-j*.018,.008,.006),M['light_cool'],holo_col,bevel=0)


def _table(name,x,y,floor,M,col,level='Ground',private=False,active=False):
    pedestal=_lathe(name+'_Pedestal',[(.32,.03),(.35,.06),(.24,.11),(.12,.53),(.22,.65)],
                     (x,y,floor),M['gold'],col)
    pedestal['seating_capacity']=4
    pedestal['level']=level
    pedestal['table_type']='Private capsule smart table' if private else 'Interactive dining table'
    top=cylinder(name+'_Stone_Top',(x,y,floor+.745),.79,.09,M['stone'],col,vertices=48)
    bevel=top.modifiers.new('Polished_Stone_Edge','BEVEL');bevel.width=.018;bevel.segments=2
    cylinder(name+'_Underside_Light',(x,y,floor+.692),.70,.018,M['light_warm'],col,vertices=32)
    _place_settings(name,x,y,floor+.794,M,col)
    _smart_menu(name,x,y,floor,M,col,active)
    for index in range(4):
        angle=index*math.pi/2
        _chair(name+'_Chair_'+str(index+1),x+1.22*math.cos(angle),y+1.22*math.sin(angle),floor,angle-math.pi/2,M,col)
    # A small living table center, not a tall visual obstruction.
    _lathe(name+'_Herb_Pot',[(.062,0),(.075,.11),(.07,.12)],(x+.13,y+.07,floor+.80),M['ivory'],col,count=16)
    for a in (0,2.1,4.2):
        leaf=sphere(name+'_Herb', (x+.13+.028*math.cos(a),y+.07+.028*math.sin(a),floor+.96),(.045,.018,.09),M['leaf'],col,segments=8,rings=4)
        leaf.rotation_euler.y=math.radians(20)


def _toilet(name,x,y,floor,M,col='37_Sanitary'):
    _lathe(name+'_Ceramic_Bowl',[(.12,0),(.15,.12),(.21,.30),(.23,.38),(.20,.41),(.17,.36),(.10,.24)],
           (x,y,floor),M['ivory'],col,count=24,elliptical=1.30)
    cube(name+'_Concealed_Cistern',(x,y+.28,floor+.52),(.50,.15,.77),M['ivory'],col,bevel=.04)
    cube(name+'_Flush_Plate',(x,y+.19,floor+.82),(.16,.014,.08),M['steel'],col,bevel=.015)
    cylinder(name+'_Seat_Water',(x,y,floor+.30),.12,.009,M['dark_glass'],col,vertices=24)


def _basin(name,x,y,floor,M,col='37_Sanitary'):
    cube(name+'_Vanity',(x,y,floor+.57),(.70,.48,.50),M['wood'],col,bevel=.04)
    _lathe(name+'_Stone_Basin',[(.14,0),(.19,.06),(.22,.14),(.19,.16),(.15,.06)],
           (x,y,floor+.84),M['stone'],col,count=24,elliptical=.82)
    curve(name+'_Sensor_Tap',[(x,y+.15,floor+.90),(x,y+.15,floor+1.17),(x,y+.01,floor+1.17)],.018,M['gold'],col)
    cube(name+'_Mirror',(x,y+.24,floor+1.52),(.64,.018,.63),M['steel'],col,bevel=.02)
    curve(name+'_Mirror_Light',[(x-.35,y+.23,floor+1.2),(x-.35,y+.23,floor+1.85),(x+.35,y+.23,floor+1.85)],.012,M['light_warm'],col)


def build_partitions(M):
    """Stage 2: tapered back-of-house rooms and legible public/service routes."""
    col='22_Interior_Partitions'
    # Kitchen front is a low service plinth with glazed vision panels above.
    for suffix,start,end in [('West',(-17.8,7.8),(-5.9,7.8)),('East',(-4.55,7.8),(-3,7.8))]:
        _wall('Kitchen_Front_'+suffix,start,end,GROUND,.95,M['wood'],col)
        _wall('Kitchen_Vision_'+suffix,start,end,GROUND+.95,2.0,M['glass'],col,thickness=.025)
    _door('Kitchen_Staff_Door',(-5.22,7.8),1.32,GROUND,2.65,M,col)
    kitchen_path=[(-17.8,7.8),(-17.6,8.25),(-15,10.05),(-10,12.1),(-4,12.7),(-3,12.55),(-3,7.8)]
    for i in range(len(kitchen_path)-1):
        _wall('Kitchen_Rear_Envelope_'+str(i),kitchen_path[i],kitchen_path[i+1],GROUND,3.25,M['ivory'],col)
    # Separate a compact pantry/cold-preparation bay while leaving an open staff aisle.
    _wall('Pantry_Divider',(-8.1,11.1),(-8.1,12.3),GROUND,2.6,M['ivory'],col)
    text('Kitchen_Wayfinding','KITCHEN  /  STAFF ONLY',(-11.0,7.70,GROUND+2.5),.23,M['gold'],rotation=(math.pi/2,0,0))
    # Accessible WC; 1.15m clear doorway, wheelchair turning circle is floor inlay.
    rooms=[('Accessible_WC',7.0,10.4,8.0,11.4,1.2),('Guest_WC',11.0,14.0,7.85,9.95,1.0),
           ('Staff_WC',4.8,6.65,11.0,12.75,.9)]
    for name,x1,x2,y1,y2,doorwidth in rooms:
        doorcenter=x1+(x2-x1)*.42
        _wall(name+'_Left',(x1,y1),(x1,y2),GROUND,2.8,M['ivory'],col)
        _wall(name+'_Back',(x1,y2),(x2,y2),GROUND,2.8,M['ivory'],col)
        _wall(name+'_Right',(x2,y2),(x2,y1),GROUND,2.8,M['ivory'],col)
        _wall(name+'_Front_A',(x1,y1),(doorcenter-doorwidth/2,y1),GROUND,2.8,M['ivory'],col)
        _wall(name+'_Front_B',(doorcenter+doorwidth/2,y1),(x2,y1),GROUND,2.8,M['ivory'],col)
        _door(name+'_Door',(doorcenter,y1),doorwidth,GROUND,2.35,M,col,glass=False)
        floor=cube(name+'_Floor',(0.5*(x1+x2),0.5*(y1+y2),GROUND+.012),(x2-x1,y2-y1,.024),M['stone'],col,bevel=0)
        floor['function']='Accessible sanitary facility' if name.startswith('Accessible') else 'Sanitary facility'
        floor['approx_area_sqm']=round((x2-x1)*(y2-y1),2)
        text(name+'_Sign','ACCESSIBLE WC' if name.startswith('Accessible') else 'WC',
             (doorcenter,y1-.09,GROUND+2.54),.135,M['gold'],rotation=(math.pi/2,0,0))
    _wall('Public_Service_Threshold_Inlay',(6.7,7.7),(17.0,7.7),GROUND,.006,M['gold'],col,thickness=.025)
    return {'kitchen_polygon': kitchen_path,'sanitary_rooms':len(rooms),'accessible_door_clear_m':1.14,
            'public_rear_aisle_m':1.65,'floor_levels_m':[GROUND,UPPER]}


def _kitchen(M):
    col='34_Kitchen_Equipment'
    # Central cooking island: front and rear staff aisles remain clear.
    cube('Kitchen_Cooking_Island_Base',(-10.3,9.45,GROUND+.44),(5.8,1.0,.82),M['steel'],col,bevel=.06)
    cube('Kitchen_Cooking_Island_Worktop',(-10.3,9.45,GROUND+.90),(5.96,1.12,.08),M['steel'],col,bevel=.018)
    fronts=[]
    for j in range(6):
        x=-12.7+j*.96
        fronts.append(((x+10.3,-.512,.45),(.83,.023,.65)))
    _boxes('Kitchen_Island_Cabinet_Fronts',fronts,(-10.3,9.45,GROUND),M['titanium'],col)
    for j in range(4):
        x=-12.35+j*1.33
        cube('Induction_Hob_'+str(j),(x,9.45,GROUND+.953),(.72,.69,.026),M['black'],col,bevel=.02)
        curve('Induction_Zone_'+str(j),[(x+.22*math.cos(a),9.45+.22*math.sin(a),GROUND+.971) for a in [math.tau*i/28 for i in range(28)]],.007,M['steel'],col,cyclic=True)
    # Sculpted extractor hood and four service hangers.
    _lathe('Kitchen_Extractor_Stem',[(.14,0),(.14,1.3)],(-10.3,9.45,GROUND+2.62),M['steel'],col,count=20)
    cube('Kitchen_Extractor_Hood',(-10.3,9.45,GROUND+2.68),(6.15,1.28,.35),M['steel'],col,bevel=.12)
    cube('Kitchen_Extractor_Light',(-10.3,9.45,GROUND+2.49),(5.72,.74,.018),M['light_warm'],col,bevel=.007)
    cube('Kitchen_Rear_Prep_Base',(-5.8,11.73,GROUND+.43),(3.6,.66,.80),M['steel'],col,bevel=.04)
    cube('Kitchen_Rear_Prep_Surface',(-5.8,11.73,GROUND+.89),(3.74,.76,.08),M['steel'],col,bevel=.012)
    # Cold storage and stacked ovens, each with glazed door and metal pulls.
    for name,x,y in [('Cold_Storage',-15.55,8.65),('Freezer',-10.7,11.47)]:
        cube(name,(x,y,GROUND+1.10),(1.2,.88,2.2),M['steel'],col,bevel=.055)
        cube(name+'_Door',(x,y-.46,GROUND+1.13),(1.08,.025,2.02),M['titanium'],col,bevel=.018)
        curve(name+'_Handle',[(x+.39,y-.50,GROUND+.73),(x+.39,y-.50,GROUND+1.50)],.022,M['gold'],col)
        cube(name+'_Status',(x-.25,y-.481,GROUND+1.87),(.28,.015,.09),M['screen'],col,bevel=.008)
    cube('Combination_Oven_Stack',(-13.85,9.0,GROUND+1.0),(.88,.84,1.95),M['steel'],col,bevel=.04)
    for j in range(2):
        cube('Oven_Glazed_Door_'+str(j),(-13.85,8.56,GROUND+.57+j*.88),(.73,.035,.63),M['dark_glass'],col,bevel=.04)
        curve('Oven_Handle_'+str(j),[(-14.13,8.50,GROUND+.80+j*.88),(-13.57,8.50,GROUND+.80+j*.88)],.022,M['steel'],col)
    # Washing corner and actual bowl/tap components.
    cube('Dishwash_Station',(-6.2,10.17,GROUND+.43),(2.2,.72,.80),M['steel'],col,bevel=.03)
    cube('Dishwash_Top',(-6.2,10.17,GROUND+.89),(2.28,.80,.07),M['steel'],col,bevel=.012)
    _lathe('Kitchen_Wash_Basin',[(.18,0),(.25,.08),(.27,.11),(.23,.13),(.16,.03)],(-6.7,10.17,GROUND+.93),M['steel'],col,count=24,elliptical=.8)
    curve('Kitchen_PreRinse_Tap',[(-6.7,10.45,GROUND+.94),(-6.7,10.45,GROUND+1.5),(-6.7,10.17,GROUND+1.5)],.018,M['steel'],col)
    for j in range(3):
        cube('Prep_Wall_Shelf_'+str(j),(-5.7,12.18,GROUND+1.25+j*.43),(3.2,.29,.035),M['steel'],col,bevel=.008)
        for k in range(4):
            cylinder('Storage_Jar_'+str(j)+'_'+str(k),(-6.8+.7*k,12.16,GROUND+1.36+j*.43),.065,.19,M['glass'],col,vertices=16)
    # Public-facing pickup counter separates delivery robots from active cooking.
    cube('Pickup_Counter_Body',(-.2,6.87,GROUND+.48),(4.8,.78,.96),M['wood'],col,bevel=.1)
    cube('Pickup_Counter_Stone',(-.2,6.87,GROUND+.99),(4.94,.91,.10),M['stone'],col,bevel=.03)
    cube('Pickup_Counter_Light',(-.2,6.46,GROUND+.54),(4.38,.018,.025),M['light_warm'],col,bevel=.006)
    text('Pickup_Wayfinding','ROBOT PICKUP  /  CHEF SERVICE',(-.2,6.40,GROUND+.78),.17,M['gold'],rotation=(math.pi/2,0,0))
    for i in range(3):
        _lathe('Pickup_Plate_'+str(i),[(.20,0),(.22,.025),(.18,.04)],(-1.55+i*1.33,6.87,GROUND+1.05),M['ivory'],col,count=24)
        sphere('Prepared_Dish_'+str(i),(-1.55+i*1.33,6.87,GROUND+1.13),(.13,.13,.07),M['leaf'],col,segments=12,rings=6)


def _reception(M):
    col='36_Reception'
    # A curved crescent desk, rather than a straight box in the arrival axis.
    verts,faces=[],[];n=40
    for height,radius in [(0,1.68),(0,2.1),(.96,1.68),(.96,2.1)]:
        for i in range(n+1):
            a=math.radians(190+160*i/n)
            verts.append((5.0+radius*math.cos(a),-10.10+radius*math.sin(a),GROUND+height))
    row=n+1
    for i in range(n):
        faces.extend([(i,i+1,row+i+1,row+i),(2*row+i,3*row+i,3*row+i+1,2*row+i+1),
                      (i,2*row+i,2*row+i+1,i+1),(row+i,row+i+1,3*row+i+1,3*row+i)])
    faces.extend([(0,row,3*row,2*row),(n,2*row-1,4*row-1,3*row-1)])
    desk=mesh('Reception_Crescent_Desk',verts,faces,M['wood'],col)
    desk['function']='Arrival and concierge reception'
    curve('Reception_Desk_Illuminated_Edge',[(5+2.1*math.cos(a),-10.1+2.1*math.sin(a),GROUND+.98) for a in [math.radians(190+160*i/n) for i in range(n+1)]],.025,M['gold'],col)
    curve('Reception_Desk_Underglow',[(5+2.11*math.cos(a),-10.1+2.11*math.sin(a),GROUND+.12) for a in [math.radians(190+160*i/n) for i in range(n+1)]],.014,M['light_warm'],col)
    tablet=cube('Concierge_Interface',(4.7,-10.78,GROUND+1.03),(.43,.30,.035),M['black'],col,bevel=.02)
    tablet.rotation_euler.x=math.radians(15)
    cube('Concierge_Interface_Display',(4.7,-10.78,GROUND+1.056),(.38,.25,.006),M['screen'],col,bevel=.008)
    text('Reception_Identity','ZENITH  /  CONCIERGE',(5.0,-11.90,GROUND+.63),.13,M['gold'],rotation=(math.pi/2,0,0))
    # Waiting lounge sits left of the ceremonial axial arrival route.
    for name,x,y,angle in [('South',-5.2,-11.0,0),('West',-7.15,-9.7,math.pi/2)]:
        sofa=cube('Waiting_Lounge_'+name,(x,y,GROUND+.33),(3.0,.86,.56),M['fabric'],col,bevel=.19)
        sofa.rotation_euler.z=angle
        back=cube('Waiting_Lounge_'+name+'_Back',(x,y+.32,GROUND+.73),(3.0,.24,.60),M['fabric'],col,bevel=.10)
        if angle:
            back.location=(x-.32,y,GROUND+.73);back.rotation_euler.z=angle
        rail=cube('Waiting_Lounge_'+name+'_Base',(x,y,GROUND+.08),(2.7,.66,.10),M['gold'],col,bevel=.04);rail.rotation_euler.z=angle
    cylinder('Waiting_Coffee_Table',(-4.95,-9.5,GROUND+.40),.62,.07,M['stone'],col,vertices=40)
    cylinder('Waiting_Coffee_Table_Pedestal',(-4.95,-9.5,GROUND+.20),.17,.36,M['gold'],col,vertices=24)


def _private_pod(name,x,y,M):
    col='35_Private_Dining'
    radius=2.35
    floor=cylinder(name+'_Floor',(x,y,UPPER+.045),radius,.09,M['wood'],col,vertices=64)
    floor['function']='Transparent private dining suite'
    floor['capacity']=4
    floor['area_sqm']=round(math.pi*radius*radius,2)
    # Curved smart glass omits a generous south-facing entry portal.
    verts,faces=[],[];n=56
    for z in (UPPER+.11,UPPER+2.88):
        for i in range(n+1):
            angle=math.radians(-50+280*i/n)
            verts.append((x+radius*math.cos(angle),y+radius*math.sin(angle),z))
    for i in range(n):faces.append((i,i+1,n+i+2,n+i+1))
    pane=mesh(name+'_Smart_Glass_Wall',verts,faces,M['glass'],col)
    solid=pane.modifiers.new('Laminated_Smart_Glass','SOLIDIFY');solid.thickness=.018
    for face in pane.data.polygons:face.use_smooth=True
    for z,suffix in [(UPPER+.12,'Floor_Rim'),(UPPER+2.89,'Canopy_Rim')]:
        curve(name+'_'+suffix,[(x+radius*math.cos(a),y+radius*math.sin(a),z) for a in [math.radians(-50+280*i/n) for i in range(n+1)]],.038,M['gold'],col)
    for index,a in enumerate((-50,20,90,160,230)):
        a=math.radians(a)
        curve(name+'_Mullion_'+str(index),[(x+radius*math.cos(a),y+radius*math.sin(a),UPPER+.12),
             (x+radius*math.cos(a),y+radius*math.sin(a),UPPER+2.89)],.021,M['gold'],col)
    # Fine radial ribs and a translucent shallow dome form the private capsule.
    verts,faces=[],[];rings=6;segments=48
    for j in range(rings+1):
        r=radius*(1-j/(rings+1))
        z=UPPER+2.89+.48*(1-(r/radius)**2)
        for i in range(segments):
            a=math.tau*i/segments
            verts.append((x+r*math.cos(a),y+r*math.sin(a),z))
    for j in range(rings):
        for i in range(segments):
            k=(i+1)%segments;faces.append((j*segments+i,j*segments+k,(j+1)*segments+k,(j+1)*segments+i))
    faces.append(tuple(rings*segments+i for i in range(segments)))
    canopy=mesh(name+'_Transparent_Canopy',verts,faces,M['glass'],col)
    for face in canopy.data.polygons:face.use_smooth=True
    for index in range(6):
        a=math.tau*index/6
        curve(name+'_Radial_Canopy_Rib_'+str(index),[(x+radius*t*math.cos(a),y+radius*t*math.sin(a),UPPER+2.89+.48*(1-t*t)) for t in [i/8 for i in range(1,9)]],.015,M['gold'],col)
    _door(name+'_Sliding_Entry',(x,y-radius+.10),1.28,UPPER+.10,2.5,M,col,sliding=True)
    text(name+'_Suite_Number',name.replace('_',' ').upper(),(x,y-radius-.035,UPPER+2.73),.13,M['gold'],rotation=(math.pi/2,0,0))
    _table(name+'_Smart_Table',x,y,UPPER+.10,M,col,level='Mezzanine',private=True,active=True)
    COUNTS['private_tables']+=1


def _robot(name,x,y,floor,M,rotation=0):
    col='39_Future_Technology'
    parts=[]
    def own(obj):parts.append(obj);return obj
    own(cube(name+'_Chassis',(x,y,floor+.17),(.63,.65,.24),M['titanium'],col,bevel=.10))
    own(_lathe(name+'_Body',[(.26,.18),(.30,.24),(.23,.70),(.18,.88)],(x,y,floor),M['ivory'],col,count=24))
    own(cube(name+'_Service_Tray',(x,y-.18,floor+.87),(.66,.68,.055),M['steel'],col,bevel=.06))
    own(cube(name+'_Tray_Recess',(x,y-.18,floor+.904),(.56,.55,.018),M['black'],col,bevel=.045))
    own(cube(name+'_Head',(x,y+.02,floor+1.17),(.54,.40,.36),M['ivory'],col,bevel=.14))
    own(cube(name+'_Face',(x,y-.19,floor+1.18),(.43,.027,.24),M['dark_glass'],col,bevel=.09))
    for side in (-1,1):
        own(sphere(name+'_Eye_'+str(side),(x+side*.105,y-.212,floor+1.19),(.038,.012,.052),M['light_cool'],col,segments=12,rings=6))
        wheel=own(cylinder(name+'_Wheel_'+str(side),(x+side*.31,y,floor+.12),.115,.07,M['black'],col,vertices=20));wheel.rotation_euler.y=math.pi/2
    own(curve(name+'_Friendly_Smile',[(x-.075,y-.215,floor+1.10),(x,y-.223,floor+1.085),(x+.075,y-.215,floor+1.10)],.008,M['light_cool'],col))
    own(_lathe(name+'_Serving_Plate',[(.19,0),(.21,.025),(.17,.04)],(x,y-.19,floor+.925),M['ivory'],col,count=24))
    own(sphere(name+'_Prepared_Food',(x,y-.19,floor+.99),(.14,.12,.055),M['leaf'],col,segments=12,rings=6))
    if rotation:
        # Curves use world-space coordinates, so a shared pivot rotates the whole assembly.
        empty=bpy.data.objects.new(name+'_Assembly',None);collection(col).objects.link(empty);empty.location=(x,y,0)
        for obj in parts:
            matrix=obj.matrix_world.copy();obj.parent=empty;obj.matrix_world=matrix
        empty.rotation_euler.z=rotation
    for obj in parts:obj['technology']='Autonomous table-delivery robot concept'
    COUNTS['serving_robots']+=1


def build_interiors(M):
    """Stage 3: dining, private suites, reception, back-of-house and future service."""
    CHAIRS.clear()
    for key in COUNTS:
        COUNTS[key] = 0
    for x in (-16.0,-10.5,10.5,16.0):
        for row,y in enumerate((-6.0,-.7,4.4)):
            if x == -16.0 and row == 1:
                continue  # Dedicated approach/landing to the architectural stair.
            name='G_Table_'+('W' if x<0 else 'E')+str(int(abs(x)*10))+'_'+str(row+1)
            _table(name,x,y,GROUND,M,'31_Ground_Dining',active=(row==0 and abs(x)==10.5))
            COUNTS['ground_tables']+=1
    for index,(x,y) in enumerate([(-14,-5),(-15,1),(-14,6),(10,-7),(15,-3)]):
        _table('M_Table_'+str(index+1),x,y,UPPER,M,'32_Mezzanine_Dining',level='Mezzanine',active=index==1)
        COUNTS['upper_tables']+=1
    _private_pod('Private_Suite_01',10,7.5,M)
    _private_pod('Private_Suite_02',16,2.5,M)
    _reception(M)
    _kitchen(M)
    # Three sanitary facilities with tangible fixtures and an accessible turning space.
    _toilet('Accessible_WC',9.5,10.65,GROUND,M)
    _basin('Accessible_WC',7.65,10.9,GROUND,M)
    curve('Accessible_Grab_Rail',[(9.95,10.35,GROUND+.72),(9.95,11.10,GROUND+.72)],.022,M['steel'],'37_Sanitary')
    curve('Accessible_Back_Rail',[(9.05,11.15,GROUND+.78),(9.95,11.15,GROUND+.78)],.022,M['steel'],'37_Sanitary')
    curve('Accessible_Turning_Inlay',[(8.65+.75*math.cos(a),9.2+.75*math.sin(a),GROUND+.028) for a in [math.tau*i/48 for i in range(48)]],.004,M['gold'],'37_Sanitary',cyclic=True)
    _toilet('Guest_WC',13.2,9.15,GROUND,M)
    _basin('Guest_WC',11.65,9.44,GROUND,M)
    _toilet('Staff_WC',5.8,12.12,GROUND,M)
    _basin('Staff_WC',5.2,11.95,GROUND,M)
    _robot('ZEN_Service_Robot_01',-.2,5.65,GROUND,M)
    _robot('ZEN_Service_Robot_02',7.55,-7.40,GROUND,M,rotation=math.radians(-25))
    # The inlaid route keeps technology part of spatial circulation, not a decoration.
    curve('Autonomous_Service_Inlay',[(-.2,6.1,GROUND+.012),(3.6,6.1,GROUND+.012),(6.8,4.8,GROUND+.012),(8.0,1.0,GROUND+.012),(8.0,-5.8,GROUND+.012),(6.2,-7.9,GROUND+.012)],.014,M['light_cool'],'39_Future_Technology')
    scene=bpy.context.scene
    scene['indoor_seating_capacity']=COUNTS['indoor_seats']
    scene['ground_dining_tables']=COUNTS['ground_tables']
    scene['mezzanine_open_tables']=COUNTS['upper_tables']
    scene['private_dining_suites']=COUNTS['private_tables']
    scene['autonomous_delivery_robots']=COUNTS['serving_robots']
    scene['interior_planning_note']='Eleven ground tables, five mezzanine tables and two four-seat private suites. West middle table omitted for stair approach.'
    return dict(COUNTS)
