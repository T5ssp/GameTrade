# Material and model guide

All materials are native editable Blender shader nodes; no texture downloads are required.

| Material | Metallic | Roughness | Role |
|---|---:|---:|---|
| Brushed champagne titanium |0.80|0.27|Split-petal roof and primary members|
| Satin architectural gold |0.82|0.24|Edge trims, handrails, signage and furniture bases|
| Warm porcelain composite |0.12|0.29|Wall and interior architectural surfaces|
| Veined pearl terrazzo |0.08|0.24|Floor plates; procedural noise and bump|
| Low-iron smart glass |0.05|0.055|Facade, lift and private dining glazing; transmission1,IOR1.46|
| Smoked walnut acoustic timber |0.03|0.43|Reception, kitchen frontage and room details|
| Deep teal woven upholstery |0|0.76|Dining and waiting furniture|
| Commercial brushed steel |0.87|0.23|Commercial kitchen equipment|
| Photovoltaic laminated cells |0.65|0.19|Roof-integrated solar geometry|

The low-iron glass, dark glass and water materials contain an explicitly named `CPU_Transparent_Shadow` Light Path branch. Camera/reflection rays retain the base PBR shader; shadow rays use a transparent approximation. Remove/bypass that mix for a fully refractive shadow setup when using a capable renderer.

## Collections

- `10_*`: foundation, ring floor plates, frame; north/south upper floor split supports cutaway presentation.
- `11_*`: ground/upper glazing panels, gold mullions, middle-floor ribbon.
- `12_Roof`: two independent sculpted roof shells, thickness modifiers and editable edge/rib curves.
- `13_Circulation`: actual stair treads, handrails, lift shaft and atrium guardrails.
- `14_*`: smart-glass oculus and its radial frame.
- `15_Entrance`, `16_Audited_Refinements`: portal and corrections to lift opening, landing, guardrails and ramp.
- `22_*`, `31_*` through `39_*`: interior partitions, dining, private suites, commercial kitchen, sanitary fixtures and future-service objects.
- `40_*`, `41_*`: visible integrated luminaires and actual area-light sources.
- `42_Solar_Integration`: individually editable photovoltaic panels and conductors following the roof curvature.
- `70_Presentation_Cameras`, `80_Wayfinding`: independent cameras and architectural text objects.
- `90_*` through `92_*`: site/arrival, landscape and outdoor terraces.

The broad `Continuous_Context_Plane` is only a matte presentation background. It is intentionally excluded from the OBJ export, so the interchange model keeps a practical site-scale bounding box.

The scene is a design model: it does not calculate energy production, operational robot navigation, structural strength or legal occupant loads.
