# The Zenith 2100 — continuation instructions

This folder is a standalone Blender architecture project, separate from the earlier restaurant website repository.

## User requirements that persist

- Keep work saved throughout the task, not only at the end. After each meaningful change, save the affected source/model and run `python3 scripts/save_checkpoint.py`. Keep `PROJECT_STATE.md` and `PROJECT_STATE.json` current so work can resume after a chat quota interruption.
- Do not claim a render, model change, installation or validation succeeded unless it was actually executed and checked.
- The user requires approval before installing software, administrative commands, dangerous system changes, or accessing unrelated files outside this project. Do not read personal files. Normal installed Blender/Python runtime resources are necessary to execute the authorized project tools.
- Blender4.3.2 is installed and validated. The user explicitly approved official Intel Open Image Denoise2.5.1 as a portable project-local tool. Its archive SHA256 and source are in `logs/oidn_installation.json`. No other installation is preapproved.
- The user explicitly authorized delivery of the completed architecture ZIP through GitHub repository T5ssp/GameTrade. The approved destination is architecture/The_Zenith_2100/. Keep delivery files separate from the website source; do not publish future unrelated modifications automatically.

## Current project

Read `PROJECT_STATE.md`, `README.md`, `logs/final_file_validation.json` and `logs/delivery_manifest.json` before resuming. The native file is `Zenith2100.blend`. Nine final presentation views and a concept plan sheet have been produced. The saved model is the authoritative editable original; OBJ is an interchange copy.

Do not re-render completed views unnecessarily. `render_presentation.py` can resume and verifies existing PNG CRC/dimensions against render records. Check whether an existing Blender process is already rendering before starting another one on the same CPU.

The camera metadata and cutaway layers are documented in `cameras/camera_manifest.json`. The complete rebuild requires build_zenith.py, then refine_architecture.py, then finalize_scene.py. Actual circulation ray tests are in audit_circulation.py and verify_zenith.py.

After model geometry changes: save the native file, rerun the appropriate geometry/opening tests, rerender affected views, verify final outputs, and refresh the project archive. A native-file modification makes the renderer conservatively recheck freshness of existing outputs.

The project is a university architectural concept. Do not present it as structural/MEP/fire-code certified construction documentation or as an operating robot/hologram system.
